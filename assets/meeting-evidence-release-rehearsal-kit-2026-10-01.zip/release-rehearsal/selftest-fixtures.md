# Synthetic engineering regression fixtures

Generated in a temporary directory by `selftest.py`; not plugin-user runs. Each checker invocation is compared with its **exact** expected exit/diagnostic set, not merely any failure. All payload inputs are synthetic copies; no original source is edited.

| Fixture/case | Mutation or scope | Expected exit | Exact diagnostic |
|---|---|---:|---|
| valid_source_zip | Unchanged explicit source + saved ZIP | 0 | none |
| valid_source_only / valid_zip_only | Each explicit-path mode | 0 | none |
| malformed_json | Broken JSON syntax | 1 | MANIFEST_JSON |
| manifest_null | Valid JSON, wrong top-level type | 1 | MANIFEST_OBJECT |
| yaml_boolean_description | Boolean-looking simple front matter | 1 | SKILL_SIMPLE_FRONTMATTER |
| required_identity | Remove manifest name | 1 | MANIFEST_REQUIRED |
| invalid_schema_name | Uppercase/underscore schema name | 1 | MANIFEST_NAME |
| mcp_component | Add recognized MCP component | 3 | COMPONENT_OUT_OF_SCOPE |
| compatibility_layout | Move root manifest into supported compatibility layout | 3 | COMPONENT_OUT_OF_SCOPE |
| bad_frontmatter | Remove delimiters | 1 | SKILL_FRONTMATTER |
| missing_skill | Remove required skill | 1 | FILE_MISSING |
| invalid_utf8 | Replace skill with invalid UTF-8 | 1 | UTF8 |
| empty_body | Preserve front matter but remove instructions | 1 | SKILL_BODY_EMPTY |
| skill_identity | Different skill name than profile directory | 1 | SKILL_IDENTITY |
| duplicate_json_key | Duplicate manifest key | 1 | MANIFEST_JSON |
| unexpected_artifact | Add authoring README inside runtime ZIP | 1 | ZIP_UNEXPECTED |
| unsafe_zip_path | Add ../escape.txt; never extract | 1 | ZIP_UNSAFE_PATH |
| zip_symlink | Add symlink member; never follow | 1 | ZIP_NOT_REGULAR |
| duplicate_zip | Duplicate exact ZIP member | 1 | ZIP_DUPLICATE |
| source_zip_mismatch | Add extra instruction to ZIP-only skill | 1 | SOURCE_ZIP_MISMATCH |
| source_symlink | Replace runtime source file with a symlink | 1 | SOURCE_SYMLINK |
| missing_source_path | Nonexistent explicit directory | 2 | SOURCE_PATH |
| cli_missing_args | No source/ZIP | 2 | argparse usage on stderr |
| cli_no_source_for_packaging | ZIP input plus write flag without source | 2 | argparse usage on stderr |
| cli_refuse_in_source_output | Packaging target inside source | 2 | argparse usage on stderr |
| cli_refuse_overwrite | Existing output target | 2 | argparse usage on stderr |
| selftest_cli_same_outputs | Identical self-test log/summary destinations | 2 | explicit different-path error on stderr |
| selftest_cli_dangling_output | Dangling symlink self-test output | 2 | explicit new-output error on stderr |
| repair_allowlisted_packaging | Source has harmless root README; package exact allowlist | 0 | ZIP_WRITTEN (INFO) |
| deterministic_second_packaging | Same source, different new output | 0 | ZIP_WRITTEN (INFO) |
| repaired_source_zip | Source compared against repaired archive | 0 | none |
| deterministic_zip_and_unchanged_payload | Compare two generated ZIP byte streams + original two payloads | invariant | bytes/payload equal |

Final recorded run: 32 subprocess commands + one deterministic invariant; 19 deliberately broken source/ZIP fixtures (including two valid-other-layout out-of-scope fixtures), one I/O-path fixture, six CLI guards and six positive commands. All 33 engineering assertions passed. These numbers are **not** host success rates, a coverage guarantee, complete schema certification or safety results. Platform acceptance of untested/unsupported variants remains unknown.
