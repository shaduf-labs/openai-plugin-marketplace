#!/usr/bin/env python3
"""Offline Meeting Evidence profile checker; no network, installation or model call."""
import argparse
import hashlib
import json
import os
import re
import stat
import sys
import unicodedata
import zipfile
from pathlib import Path

SCHEMA = 'https://agent-plugins.org/schemas/1.0.0/plugin.schema.json'
PROFILE = 'meeting-evidence-two-file-skills-only-v1'
FILES = ('plugin.json', 'skills/meeting-evidence/SKILL.md')
REQUIRED = {'$schema', 'name', 'version', 'description'}
SCHEMA_KEYS = REQUIRED | {'author', 'homepage', 'repository', 'license', 'keywords', 'extensions'}
MAX_MEMBER = 1024 * 1024
MAX_ARCHIVE = 4 * 1024 * 1024
PENDING = {key: 'NOT RUN' for key in ('host_installation_compatibility', 'explicit_skill_selection',
    'implicit_activation', 'model_output_quality', 'security_evaluation', 'portal_upload_validation',
    'final_public_validation', 'skill_safety_scan', 'review', 'approval', 'chosen_plugin_publication')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Check:
    def __init__(self):
        self.diagnostics = []
        self.identities = {}
        self.hashes = {}

    def add(self, level, code, where, detail):
        self.diagnostics.append({'level': level, 'code': code, 'where': str(where), 'detail': detail})

    def unsupported(self, path):
        parts = path.split('/')
        return parts[0] in {'mcp.json', '.mcp.json', '.app.json', '.codex-plugin', '.claude-plugin',
                            'hooks', 'assets', 'scripts', 'agents'} or (
            len(parts) > 1 and parts[0] == 'skills' and parts[1] != 'meeting-evidence')

    def source(self, root):
        if not root.exists() or not root.is_dir():
            self.add('IO', 'SOURCE_PATH', root, 'Explicit source path must be an existing directory.')
            return None
        if root.is_symlink():
            self.add('ERROR', 'SOURCE_SYMLINK', root, 'Kit policy rejects a symlink source root.')
            return None
        # Root authoring aids may exist; they are never in the runtime allowlist.
        for child in sorted(root.iterdir()):
            if self.unsupported(child.name):
                self.add('OUT_OF_SCOPE', 'COMPONENT_OUT_OF_SCOPE', child,
                         'Other layouts/components can be valid; this two-file profile does not evaluate them.')
        if not (root / 'plugin.json').exists() and any((root / p / 'plugin.json').exists() for p in ('.codex-plugin', '.claude-plugin')):
            return None
        skills = root / 'skills'
        if skills.is_dir() and not skills.is_symlink():
            for child in sorted(skills.iterdir()):
                rel = child.relative_to(root).as_posix()
                if rel != 'skills/meeting-evidence':
                    self.add('OUT_OF_SCOPE', 'SKILL_LAYOUT_OUT_OF_SCOPE', child,
                             'Only skills/meeting-evidence is in this profile.')
        skillroot = skills / 'meeting-evidence'
        if skillroot.is_dir() and not skillroot.is_symlink():
            for child in sorted(skillroot.iterdir()):
                if child.name != 'SKILL.md':
                    self.add('OUT_OF_SCOPE', 'SKILL_RESOURCE_OUT_OF_SCOPE', child,
                             'Additional skill resources are not evaluated or packaged by this profile.')
        data = {}
        for rel in FILES:
            path = root / rel
            parents = [root / Path(*Path(rel).parts[:n]) for n in range(1, len(Path(rel).parts) + 1)]
            if any(p.is_symlink() for p in parents):
                self.add('ERROR', 'SOURCE_SYMLINK', path, 'Kit policy rejects symlinks in runtime paths.')
                continue
            try:
                info = path.stat()
                if not stat.S_ISREG(info.st_mode):
                    self.add('ERROR', 'SOURCE_NOT_REGULAR', path, 'Required runtime entry must be a regular file.')
                    continue
                if info.st_size > MAX_MEMBER:
                    self.add('ERROR', 'SOURCE_LIMIT', path, 'Kit policy limit: 1 MiB per runtime file.')
                    continue
                data[rel] = path.read_bytes()
            except FileNotFoundError:
                self.add('ERROR', 'FILE_MISSING', path, 'Required profile runtime file is missing.')
            except OSError as exc:
                self.add('IO', 'SOURCE_READ', path, str(exc))
        self.payload(data, 'source')
        return data

    def archive(self, path):
        if not path.is_file():
            self.add('IO', 'ZIP_PATH', path, 'Explicit ZIP path must be an existing file.')
            return None
        if path.is_symlink():
            self.add('ERROR', 'ZIP_SYMLINK', path, 'Kit policy rejects a symlink archive path.')
            return None
        data = {}
        try:
            if path.stat().st_size > MAX_ARCHIVE:
                self.add('ERROR', 'ZIP_LIMIT', path, 'Kit policy compressed archive limit: 4 MiB.')
                return None
            with zipfile.ZipFile(path) as archive:
                members = archive.infolist()
                if len(members) > 16:
                    self.add('ERROR', 'ZIP_LIMIT', path, 'Kit policy member-count limit: 16.')
                    return None
                seen = set()
                readable = []
                for info in members:
                    name = info.filename
                    parts = name.split('/')
                    if not name or name != name.strip() or '\\' in name or name.startswith('/') or any(
                            part in {'', '.', '..'} or ':' in part for part in parts) or any(
                            ord(c) < 32 or ord(c) == 127 for c in name):
                        self.add('ERROR', 'ZIP_UNSAFE_PATH', name, 'Kit policy rejects unsafe/noncanonical paths; no extraction is performed.')
                        continue
                    key = unicodedata.normalize('NFC', name).casefold()
                    if key in seen:
                        self.add('ERROR', 'ZIP_DUPLICATE', name, 'Kit policy rejects duplicate/case/Unicode-colliding paths.')
                        continue
                    seen.add(key)
                    mode = (info.external_attr >> 16) & 0xFFFF
                    kind = stat.S_IFMT(mode)
                    if info.is_dir() or kind not in {0, stat.S_IFREG}:
                        self.add('ERROR', 'ZIP_NOT_REGULAR', name, 'Kit policy accepts only two regular files, not directories/symlinks/special entries.')
                        continue
                    if info.flag_bits & 1:
                        self.add('ERROR', 'ZIP_ENCRYPTED', name, 'Encrypted archives are not supported by this kit.')
                        continue
                    if name not in FILES:
                        if self.unsupported(name):
                            self.add('OUT_OF_SCOPE', 'COMPONENT_OUT_OF_SCOPE', name, 'Recognized other component/layout; not evaluated by this kit.')
                        else:
                            self.add('ERROR', 'ZIP_UNEXPECTED', name, 'Not in the two-file runtime allowlist; do not ship authoring aids.')
                        continue
                    if info.file_size > MAX_MEMBER:
                        self.add('ERROR', 'ZIP_LIMIT', name, 'Kit policy uncompressed file limit: 1 MiB.')
                        continue
                    readable.append(info)
                # Reads validate CRC for the only allowlisted members. Never extract.
                for info in readable:
                    data[info.filename] = archive.read(info)
        except (OSError, zipfile.BadZipFile, RuntimeError, NotImplementedError, EOFError) as exc:
            self.add('ERROR', 'ZIP_INVALID', path, 'Cannot read allowlisted ZIP bytes/CRC: ' + str(exc))
            return None
        for rel in FILES:
            if rel not in data:
                self.add('ERROR', 'ZIP_MISSING', rel, 'Required runtime file absent or rejected from ZIP.')
        self.hashes['archive_sha256'] = digest(path.read_bytes())
        self.payload(data, 'zip')
        return data

    def payload(self, data, label):
        self.hashes[label] = {name: digest(value) for name, value in sorted(data.items())}
        decoded = {}
        for rel, value in data.items():
            try:
                decoded[rel] = value.decode('utf-8')
            except UnicodeDecodeError as exc:
                self.add('ERROR', 'UTF8', label + ':' + rel, str(exc))
        manifest_text = decoded.get('plugin.json')
        if manifest_text is not None:
            def pairs(items):
                out = {}
                for key, value in items:
                    if key in out:
                        raise ValueError('Duplicate JSON key: ' + key)
                    out[key] = value
                return out
            try:
                obj = json.loads(manifest_text, object_pairs_hook=pairs,
                                 parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON value: ' + value)))
            except ValueError as exc:
                self.add('ERROR', 'MANIFEST_JSON', label + ':plugin.json', str(exc))
            else:
                self.manifest(obj, label)
        skill_text = decoded.get(FILES[1])
        if skill_text is not None:
            self.skill(skill_text, label)

    def manifest(self, obj, label):
        where = label + ':plugin.json'
        if not isinstance(obj, dict):
            self.add('ERROR', 'MANIFEST_OBJECT', where, 'Manifest must be a JSON object.')
            return
        missing = sorted(REQUIRED - set(obj))
        if missing:
            self.add('ERROR', 'MANIFEST_REQUIRED', where, 'Required by this profile: ' + ', '.join(missing) + '; schema itself requires only $schema/name.')
        extra = set(obj) - REQUIRED
        if extra:
            known = extra & (SCHEMA_KEYS - REQUIRED | {'skills', 'mcpServers', 'apps', 'hooks', 'interface'})
            if known:
                self.add('OUT_OF_SCOPE', 'MANIFEST_OUT_OF_SCOPE', where, 'Additional metadata/compatibility/component fields not evaluated: ' + ', '.join(sorted(known)))
            unknown = extra - known
            if unknown:
                self.add('ERROR', 'MANIFEST_UNKNOWN', where, 'Unknown top-level fields outside the finite profile: ' + ', '.join(sorted(unknown)))
        if '$schema' in obj and obj['$schema'] != SCHEMA:
            self.add('OUT_OF_SCOPE', 'SCHEMA_OUT_OF_SCOPE', where, 'Only the Agent Plugins 1.0.0 schema identifier is evaluated.')
        name = obj.get('name')
        if 'name' in obj:
            if not isinstance(name, str) or not 1 <= len(name) <= 64 or not re.fullmatch(r'(?!.*(?:--|\.\.))[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?', name):
                self.add('ERROR', 'MANIFEST_NAME', where, 'Name does not meet the checked 1.0.0 schema name rule.')
            elif name != 'meeting-evidence':
                self.add('OUT_OF_SCOPE', 'IDENTITY_OUT_OF_SCOPE', where, 'This kit checks meeting-evidence, not other valid plugin identities.')
        version = obj.get('version')
        if 'version' in obj and (not isinstance(version, str) or not re.fullmatch(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)', version)):
            self.add('OUT_OF_SCOPE', 'VERSION_OUT_OF_SCOPE', where, 'Kit release policy supports numeric major.minor.patch only; schema merely types version as a string.')
        if 'description' in obj and (not isinstance(obj['description'], str) or not obj['description'].strip()):
            self.add('ERROR', 'MANIFEST_DESCRIPTION', where, 'This profile requires a nonempty string description.')
        self.identities[label] = {'name': name, 'version': version, 'schema': obj.get('$schema')}

    def skill(self, content, label):
        where = label + ':' + FILES[1]
        lines = content.splitlines()
        if not lines or lines[0] != '---' or '---' not in lines[1:]:
            self.add('ERROR', 'SKILL_FRONTMATTER', where, 'Expected opening/closing --- lines.')
            return
        close = lines.index('---', 1)
        front = {}
        for line in lines[1:close]:
            match = re.fullmatch(r'(name|description): ([^\r\n]+)', line)
            if not match or match[1] in front or match[2][0] in '\"\'[{&*!|>@`' or ' #' in match[2] or ': ' in match[2] or match[2].lower() in {'true', 'false', 'yes', 'no', 'on', 'off', 'null', '~'} or re.fullmatch(r'[+-]?[0-9.]+', match[2]):
                self.add('ERROR', 'SKILL_SIMPLE_FRONTMATTER', where, 'Profile supports exactly name/description as plain single-line strings, not arbitrary YAML.')
                return
            front[match[1]] = match[2]
        if set(front) != {'name', 'description'}:
            self.add('ERROR', 'SKILL_SIMPLE_FRONTMATTER', where, 'Both name and description are required by this simple profile.')
            return
        if front['name'] != 'meeting-evidence':
            self.add('ERROR', 'SKILL_IDENTITY', where, 'Skill name must match the meeting-evidence directory/profile identity.')
        if not front['description'].strip() or len(front['description']) > 1024:
            self.add('ERROR', 'SKILL_DESCRIPTION', where, 'Description must be nonempty and at most 1024 characters.')
        if not '\n'.join(lines[close + 1:]).strip():
            self.add('ERROR', 'SKILL_BODY_EMPTY', where, 'Skill instructions are empty.')

    def result(self, inputs):
        levels = {d['level'] for d in self.diagnostics}
        exit_code = 2 if 'IO' in levels else 1 if 'ERROR' in levels else 3 if 'OUT_OF_SCOPE' in levels else 0
        return {'evidence_kind': 'offline engineering checks; not plugin behavior', 'profile': PROFILE,
                'scope': 'Two runtime files; finite manifest subset; simple front matter; allowlisted paths, CRC reads and optional source/ZIP byte comparison. Not full schema, YAML, secret/safety scan or host validation.',
                'inputs': inputs, 'identities': self.identities, 'hashes': self.hashes,
                'status': {0: 'PASS_SCOPED_OFFLINE', 1: 'FAIL_SCOPED_OFFLINE', 2: 'IO_ERROR', 3: 'OUT_OF_SCOPE'}[exit_code],
                'exit_code': exit_code, 'diagnostics': self.diagnostics, 'pending_gates': PENDING,
                'submission_ready': False}


def write_zip(path, data):
    # ZIP_STORED avoids compressor-version differences; bytes, ordering, timestamps and Unix modes are fixed.
    with path.open('xb') as output:
        with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as archive:
            for rel in sorted(FILES):
                info = zipfile.ZipInfo(rel, date_time=(2026, 9, 29, 0, 0, 0))
                info.create_system = 3
                info.compress_type = zipfile.ZIP_STORED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data[rel])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, help='Explicit source-package directory')
    parser.add_argument('--runtime-zip', type=Path, help='Explicit existing runtime ZIP (read without extraction)')
    parser.add_argument('--write-zip', type=Path, help='New deterministic runtime ZIP outside the source; never overwrites')
    parser.add_argument('--json', type=Path, help='New machine-evidence JSON path outside the source; never overwrites')
    args = parser.parse_args(argv)
    if not args.source and not args.runtime_zip:
        parser.error('Provide --source and/or --runtime-zip.')
    if args.write_zip and not args.source:
        parser.error('--write-zip requires --source.')
    if args.write_zip and args.runtime_zip:
        parser.error('Use --runtime-zip to inspect OR --write-zip to package, not both.')
    targets = [path for path in (args.write_zip, args.json) if path]
    if len({str(p.absolute()) for p in targets}) != len(targets):
        parser.error('Output paths must differ.')
    for path in targets:
        if path.exists() or path.is_symlink():
            parser.error('Refusing to overwrite output: ' + str(path))
        if args.source and (path.resolve() == args.source.resolve() or args.source.resolve() in path.resolve().parents):
            parser.error('Outputs must be outside the source-package directory.')
        if not path.parent.is_dir():
            parser.error('Output parent must already exist: ' + str(path.parent))
    checker = Check()
    source = checker.source(args.source) if args.source else None
    zipped = checker.archive(args.runtime_zip) if args.runtime_zip else None
    if source is not None and zipped is not None:
        for rel in FILES:
            if rel in source and rel in zipped and source[rel] != zipped[rel]:
                checker.add('ERROR', 'SOURCE_ZIP_MISMATCH', rel, 'Source and runtime ZIP bytes differ; inspect version/content and repackage.')
    if args.write_zip and checker.result({})['exit_code'] == 0:
        try:
            write_zip(args.write_zip, source)
            checker.archive(args.write_zip)
            checker.add('INFO', 'ZIP_WRITTEN', args.write_zip, 'Wrote exactly the two allowlisted files; deterministic stored ZIP.')
        except OSError as exc:
            checker.add('IO', 'ZIP_WRITE', args.write_zip, str(exc))
    inputs = {key: str(value) if value else None for key, value in vars(args).items()}
    result = checker.result(inputs)
    if args.json:
        try:
            with args.json.open('x', encoding='utf-8') as output:
                json.dump(result, output, indent=2, ensure_ascii=False)
                output.write('\n')
        except OSError as exc:
            checker.add('IO', 'SUMMARY_WRITE', args.json, str(exc))
            result = checker.result(inputs)
    for item in result['diagnostics']:
        print('{level} {code} [{where}]: {detail}'.format(**item))
    print(result['status'] + ': ' + PROFILE)
    print('NOT RUN: host behavior, security evaluation, public validation/scans, review/approval/publication. NOT SUBMISSION-READY.')
    return result['exit_code']


if __name__ == '__main__':
    sys.exit(main())
