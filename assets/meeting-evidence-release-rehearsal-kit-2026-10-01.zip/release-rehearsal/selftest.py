#!/usr/bin/env python3
"""Synthetic checker regressions, not model/plugin behavior tests. Standard library only."""
import argparse
import hashlib
import json
import platform
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
RELS = ('plugin.json', 'skills/meeting-evidence/SKILL.md')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log', type=Path, help='New log path; never overwrite')
    parser.add_argument('--summary', type=Path, help='New JSON summary path; never overwrite')
    args = parser.parse_args()
    if args.log and args.summary and args.log.resolve() == args.summary.resolve():
        parser.error('--log and --summary output paths must differ.')
    for target in (args.log, args.summary):
        if target and (target.exists() or target.is_symlink() or not target.parent.is_dir()):
            parser.error('Output must be new with existing parent: ' + str(target))
    log = ['ENGINEERING SELF-TESTS ONLY. Host/model/security/public results remain NOT RUN.']
    records = []
    before = {rel: hashlib.sha256((HERE / 'source' / rel).read_bytes()).hexdigest() for rel in RELS}
    with tempfile.TemporaryDirectory(prefix='meeting-evidence-rehearsal-') as temp:
        work = Path(temp)
        def source(case):
            dest = work / case
            shutil.copytree(HERE / 'source', dest)
            return dest
        def archive(case, changes=None, extra=None):
            dest = work / (case + '.zip')
            data = {rel: (HERE / 'source' / rel).read_bytes() for rel in RELS}
            data.update(changes or {})
            with zipfile.ZipFile(dest, 'w') as handle:
                for rel, content in data.items():
                    handle.writestr(rel, content)
                for info, content in extra or []:
                    handle.writestr(info, content)
            return dest
        def run(case, flags, exit_expected, codes=(), cli=False, program='rehearse.py', stderr_contains=None):
            command = [sys.executable, str(HERE / program), *map(str, flags)]
            machine = work / (case + '.json')
            if not cli:
                command.extend(['--json', str(machine)])
            result = subprocess.run(command, capture_output=True, text=True)
            evidence = json.loads(machine.read_text()) if machine.exists() else None
            actual_codes = [d['code'] for d in evidence['diagnostics']] if evidence else []
            pending_ok = evidence is None or (all(v == 'NOT RUN' for v in evidence['pending_gates'].values()) and not evidence['submission_ready'])
            ok = result.returncode == exit_expected and set(actual_codes) == set(codes) and pending_ok and (stderr_contains is None or stderr_contains in result.stderr)
            record = {'id': case, 'command': shlex.join(command), 'expected_exit': exit_expected,
                      'actual_exit': result.returncode, 'expected_stderr_contains': stderr_contains, 'expected_codes': list(codes), 'actual_codes': actual_codes,
                      'stdout': result.stdout, 'stderr': result.stderr, 'tooling_assertion_passed': ok,
                      'evidence': evidence}
            records.append(record)
            log.extend(['\nCASE ' + case, '$ ' + record['command'], result.stdout.rstrip(),
                        'stderr: ' + result.stderr.rstrip(), 'exit: ' + str(result.returncode),
                        'expected exit/codes: ' + str(exit_expected) + ' / ' + ','.join(codes),
                        'TOOLING ASSERTION: ' + ('PASS' if ok else 'FAIL')])
            print(case + ': ' + ('PASS' if ok else 'FAIL') + ' (actual exit ' + str(result.returncode) + ')')
            return ok

        run('valid_source_zip', ['--source', HERE / 'source', '--runtime-zip', HERE / 'runtime/meeting-evidence-0.1.0.zip'], 0)
        run('valid_source_only', ['--source', HERE / 'source'], 0)
        run('valid_zip_only', ['--runtime-zip', HERE / 'runtime/meeting-evidence-0.1.0.zip'], 0)
        p = source('malformed_json'); (p / RELS[0]).write_text('{ broken', encoding='utf-8')
        run('malformed_json', ['--source', p], 1, ['MANIFEST_JSON'])
        p = source('manifest_null'); (p / RELS[0]).write_text('null')
        run('manifest_null', ['--source', p], 1, ['MANIFEST_OBJECT'])
        p = source('yaml_boolean_description'); (p / RELS[1]).write_text('---\nname: meeting-evidence\ndescription: true\n---\nRecap notes.\n')
        run('yaml_boolean_description', ['--source', p], 1, ['SKILL_SIMPLE_FRONTMATTER'])
        p = source('required_identity'); obj = json.loads((p / RELS[0]).read_text()); del obj['name']; (p / RELS[0]).write_text(json.dumps(obj))
        run('required_identity', ['--source', p], 1, ['MANIFEST_REQUIRED'])
        p = source('invalid_schema_name'); obj = json.loads((p / RELS[0]).read_text()); obj['name'] = 'Meeting_Evidence'; (p / RELS[0]).write_text(json.dumps(obj))
        run('invalid_schema_name', ['--source', p], 1, ['MANIFEST_NAME'])
        p = source('mcp_component'); (p / 'mcp.json').write_text('{"mcpServers":{}}')
        run('mcp_component', ['--source', p], 3, ['COMPONENT_OUT_OF_SCOPE'])
        p = source('compatibility_layout'); (p / '.codex-plugin').mkdir(); (p / 'plugin.json').rename(p / '.codex-plugin/plugin.json')
        run('compatibility_layout', ['--source', p], 3, ['COMPONENT_OUT_OF_SCOPE'])
        p = source('bad_frontmatter'); (p / RELS[1]).write_text('name: meeting-evidence\nNo delimiter\n')
        run('bad_frontmatter', ['--source', p], 1, ['SKILL_FRONTMATTER'])
        p = source('missing_skill'); (p / RELS[1]).unlink()
        run('missing_skill', ['--source', p], 1, ['FILE_MISSING'])
        p = source('invalid_utf8'); (p / RELS[1]).write_bytes(b'\xff\xfe')
        run('invalid_utf8', ['--source', p], 1, ['UTF8'])
        p = source('empty_body'); (p / RELS[1]).write_text('---\nname: meeting-evidence\ndescription: Summarize supplied notes.\n---\n')
        run('empty_body', ['--source', p], 1, ['SKILL_BODY_EMPTY'])
        p = source('skill_identity'); (p / RELS[1]).write_text((p / RELS[1]).read_text().replace('name: meeting-evidence', 'name: other-skill', 1))
        run('skill_identity', ['--source', p], 1, ['SKILL_IDENTITY'])
        p = source('duplicate_json_key'); (p / RELS[0]).write_text('{"name":"meeting-evidence","name":"meeting-evidence"}')
        run('duplicate_json_key', ['--source', p], 1, ['MANIFEST_JSON'])
        p = archive('unexpected_artifact', extra=[('README.md', b'Authoring aid: never runtime')])
        run('unexpected_artifact', ['--runtime-zip', p], 1, ['ZIP_UNEXPECTED'])
        p = archive('unsafe_zip_path', extra=[('../escape.txt', b'Never extracted')])
        run('unsafe_zip_path', ['--runtime-zip', p], 1, ['ZIP_UNSAFE_PATH'])
        info = zipfile.ZipInfo('linked.txt'); info.create_system = 3; info.external_attr = (stat.S_IFLNK | 0o777) << 16
        p = archive('zip_symlink', extra=[(info, b'/etc/passwd')])
        run('zip_symlink', ['--runtime-zip', p], 1, ['ZIP_NOT_REGULAR'])
        p = archive('duplicate_zip', extra=[('plugin.json', (HERE / 'source/plugin.json').read_bytes())])
        run('duplicate_zip', ['--runtime-zip', p], 1, ['ZIP_DUPLICATE'])
        p = archive('source_zip_mismatch', changes={RELS[1]: (HERE / 'source' / RELS[1]).read_bytes() + b'\nSynthetic extra instruction.\n'})
        run('source_zip_mismatch', ['--source', HERE / 'source', '--runtime-zip', p], 1, ['SOURCE_ZIP_MISMATCH'])
        p = source('source_symlink'); (p / RELS[1]).unlink(); (p / RELS[1]).symlink_to(HERE / 'source' / RELS[1])
        run('source_symlink', ['--source', p], 1, ['SOURCE_SYMLINK'])
        run('missing_source_path', ['--source', work / 'does-not-exist'], 2, ['SOURCE_PATH'])
        run('cli_missing_args', [], 2, cli=True, stderr_contains='Provide --source and/or --runtime-zip.')
        run('cli_no_source_for_packaging', ['--runtime-zip', HERE / 'runtime/meeting-evidence-0.1.0.zip', '--write-zip', work / 'new.zip'], 2, cli=True, stderr_contains='--write-zip requires --source.')
        run('cli_refuse_in_source_output', ['--source', HERE / 'source', '--write-zip', HERE / 'source' / 'forbidden.zip'], 2, cli=True, stderr_contains='Outputs must be outside the source-package directory.')
        p = work / 'already.zip'; p.write_bytes(b'keep')
        run('cli_refuse_overwrite', ['--source', HERE / 'source', '--write-zip', p], 2, cli=True, stderr_contains='Refusing to overwrite output:')
        p = work / 'same-evidence';
        run('selftest_cli_same_outputs', ['--log', p, '--summary', p], 2, cli=True, program='selftest.py', stderr_contains='--log and --summary output paths must differ.')
        p = work / 'dangling-evidence'; p.symlink_to(work / 'absent-target')
        run('selftest_cli_dangling_output', ['--log', p], 2, cli=True, program='selftest.py', stderr_contains='Output must be new with existing parent:')
        # Concrete repair: keep README in source, use allowlisting rather than recursively archiving it.
        p = source('repair_source'); (p / 'README.md').write_text('authoring aid only')
        zip_a, zip_b = work / 'repaired-a.zip', work / 'repaired-b.zip'
        run('repair_allowlisted_packaging', ['--source', p, '--write-zip', zip_a], 0, ['ZIP_WRITTEN'])
        run('deterministic_second_packaging', ['--source', p, '--write-zip', zip_b], 0, ['ZIP_WRITTEN'])
        run('repaired_source_zip', ['--source', p, '--runtime-zip', zip_a], 0)
        stable = zip_a.read_bytes() == zip_b.read_bytes()
        original_payload = {rel: (HERE / 'source' / rel).read_bytes() for rel in RELS}
        with zipfile.ZipFile(zip_a) as handle:
            payload_equal = handle.namelist() == sorted(RELS) and all(handle.read(rel) == content for rel, content in original_payload.items())
        invariant = {'id': 'deterministic_zip_and_unchanged_payload', 'tooling_assertion_passed': stable and payload_equal,
                     'archive_a_sha256': hashlib.sha256(zip_a.read_bytes()).hexdigest(),
                     'archive_b_sha256': hashlib.sha256(zip_b.read_bytes()).hexdigest(),
                     'bytes_equal': stable, 'allowlisted_payload_equals_unchanged_source': payload_equal}
        records.append(invariant); log.append('\nINVARIANT ' + json.dumps(invariant, sort_keys=True))
    after = {rel: hashlib.sha256((HERE / 'source' / rel).read_bytes()).hexdigest() for rel in RELS}
    preserved = before == after
    ok = all(record['tooling_assertion_passed'] for record in records) and preserved
    summary = {'evidence_kind': 'checker self-tests only; not plugin/model/security/public behavior',
               'checked_at': datetime.now(timezone.utc).isoformat(), 'python': platform.python_version(),
               'profile': 'meeting-evidence-two-file-skills-only-v1', 'overall_tooling_assertions_passed': ok,
               'record_count': len(records), 'command_count': sum('command' in r for r in records),
               'records': records, 'source_hashes_before': before, 'source_hashes_after': after,
               'source_unchanged': preserved, 'host_behavior': 'NOT RUN', 'public_validation_review': 'NOT RUN',
               'plugin_safety': 'NOT RUN', 'submission_ready': False,
               'temporary_fixture_paths': 'Scratch fixtures removed after execution; recreate with this selftest.py.'}
    log.append('\nSELF-TEST ' + ('PASS' if ok else 'FAIL') + '; host/public NOT RUN; no model success rate computed.')
    if args.log:
        args.log.write_text('\n'.join(log) + '\n', encoding='utf-8')
    if args.summary:
        args.summary.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(log[-1])
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
