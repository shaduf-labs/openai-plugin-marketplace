# Meeting Evidence release rehearsal

Original offline engineering kit, checked **2026-10-01**, for the unchanged Meeting Evidence **0.1.0** teaching source. Python 3 standard library only; no login, dependency install, API key, catalog edits, network, model invocation or package installation.

**A scoped offline pass is not host compatibility, skill activation, output quality, a security scan, public validation, approval or submission readiness.** `host-cases.json` contains ten manual specifications; every actual field is **NOT RUN**.

## Run after extracting the kit

From this `release-rehearsal/` directory:

```sh
python3 rehearse.py --source source --runtime-zip runtime/meeting-evidence-0.1.0.zip
python3 selftest.py
```

Both commands should exit `0` for the supplied files. The self-test's PASS labels are **checker assertions**, never plugin successes. Synthetic negative checks intentionally return `1` or `3`; the self-test itself returns `0` only when their exact expected diagnostic sets and exits match.

Explicit paths allow checking another copy without rewriting its repository:

```sh
python3 rehearse.py --source /absolute/path/to/source --runtime-zip /absolute/path/to/runtime.zip
python3 rehearse.py --source source --json ../fresh-evidence.json
python3 selftest.py --log ../fresh-selftest.log --summary ../fresh-selftest.json
```

Choose new output filenames; existing outputs are refused. Output parents must exist. Checker outputs must stay outside the source directory. No arguments, incompatible packaging flags, overwrite requests or in-source outputs return CLI exit `2` with help/diagnostics on stderr. A ZIP-only check cannot establish source equivalence; a source-only check cannot establish packaged bytes. Machine evidence includes profile, inputs, identity/version, hashes, diagnostics and pending gates.

## Exactly what this profile checks

Profile: `meeting-evidence-two-file-skills-only-v1`. Runtime allowlist:

- `plugin.json`
- `skills/meeting-evidence/SKILL.md`

Finite manifest subset: UTF-8; strict JSON object (duplicate keys and nonfinite numbers rejected); four profile fields `$schema`, `name`, `version`, `description`; exact Agent Plugins 1.0.0 schema URL; its checked name type/length/pattern; fixed `meeting-evidence` identity; nonempty string description; numeric `major.minor.patch` release policy (no leading zeroes). **The external schema requires only `$schema` and `name`; our version/description/exact-name/numeric-version requirements are narrower profile choices, not universal platform requirements.** We do not implement full JSON Schema or all semantic/operational requirements.

The skill must occupy the exact allowlisted path, decode as UTF-8, begin/end its front matter with `---`, contain exactly plain single-line `name`/`description` fields matching this profile, and have nonempty instructions. This is a deliberately restricted grammar, **not a YAML parser**. Quoted/multiline YAML and additional metadata/resources need a different checker; rejection here does not establish platform invalidity. Description limit and combined identity are bounded to this sample (the fixed combined name is 33 characters).

Recognized compatibility manifests, MCP/app files, hooks, icons/assets, scripts, other skill layouts, additional portable metadata/extensions or versions outside the numeric release profile receive **OUT_OF_SCOPE**, not universal-invalid claims. The source may contain root authoring aids such as README/tests; they are not interpreted and never packaged. Additional content within the one skill folder is out of scope to avoid accidentally dropping a skill resource. This is not a broad source inventory, dependency checker, secret detector or safety scanner.

Our conservative packaging policy rejects symlinks in selected source paths, unsafe/noncanonical ZIP paths, duplicate/case/Unicode-colliding entries, encrypted entries, symlinks/special files/directory members, unexpected runtime artifacts, more than 16 ZIP entries, archives above 4 MiB or runtime files above 1 MiB. These are **kit policies, not a complete reproduction of portal archive rules**. Archives are read using an exact allowlist and never extracted; CRC is checked when those members are read. Both supplied paths cause a byte-for-byte runtime/source comparison, not a comparison of model behavior.

Exit codes: `0` scoped offline pass; `1` checked-profile/packaging error; `2` CLI or I/O error; `3` recognized out-of-scope profile/layout. If several conditions occur, I/O takes priority, then checked errors, then out-of-scope. Read the complete diagnostics rather than only the final code.

## Make a deterministic runtime ZIP

```sh
python3 rehearse.py --source source --write-zip ../new-runtime.zip
python3 rehearse.py --source source --runtime-zip ../new-runtime.zip
```

Only the two runtime files are written, sorted, with fixed date/Unix mode and ZIP_STORED compression. Running twice to distinct new paths produces identical bytes for identical runtime inputs in our observed Python 3.11.2 regression. The original supplied runtime ZIP is kept unchanged and uses a different compression encoding: **payload identity is established; new packaging is not claimed byte-identical to that old ZIP.** Determinism is an engineering property, not correctness or safety.

## Reproduce an actual failure → repair

Accidentally shipping an authoring README is the self-test `unexpected_artifact`. Use a scratch directory, leaving original source/runtime untouched:

```sh
mkdir -p ../scratch
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
with ZipFile('runtime/meeting-evidence-0.1.0.zip') as original, ZipFile('../scratch/accidental.zip', 'w') as bad:
    for item in original.infolist():
        bad.writestr(item.filename, original.read(item.filename))
    bad.writestr('README.md', 'Authoring aid, not runtime')
PY
python3 rehearse.py --source source --runtime-zip ../scratch/accidental.zip
# Expected: ERROR ZIP_UNEXPECTED [README.md] ... ; exit 1
python3 rehearse.py --source source --write-zip ../scratch/repaired.zip
# Expected: INFO ZIP_WRITTEN ... ; PASS_SCOPED_OFFLINE ; exit 0
python3 rehearse.py --source source --runtime-zip ../scratch/repaired.zip
# Expected: PASS_SCOPED_OFFLINE ; exit 0
```

The repair changes the packaging command, not the runtime skill or version. No credentials, source broadening or portal submission are needed. Our actual synthetic failure/repair and exact commands/exits are saved in `evidence/validation.log` and `evidence/validation-summary.json`. Scratch fixtures are generated by `selftest.py` and removed after execution; `selftest-fixtures.md` explains each.

## What remains after this pass

1. Establish lawful account/workspace access and **actual supported-host package compatibility**. Current [submission/package metadata guidance](https://developers.openai.com/plugins/deploy/submission) says Codex package validation requires `logo` and `composerIcon`; the preserved two-file example has neither. A portable upload can omit them, but a primary icon is required before public submission. Do not call this ZIP Codex-ready. Adding required metadata/assets goes outside this checker profile; use an appropriate validator and record the resulting source/version/hash.
2. Install through a supported local source in a separate trusted test repository; preserve/merge the existing catalog, record the client/version and loaded source, and start a new session. Follow current [package instructions](https://developers.openai.com/plugins/build/plugins) and [host guide](https://learn.chatgpt.com/docs/plugins); installation still does not prove activation.
3. Fill `host-evidence-template.json` for explicit selection, implicit activation, quality, missing input, contradictions/injection and outside-action boundaries. Use `host-cases.json` and `host-rubric.md`; a correct answer alone is not activation evidence. Do not estimate model success from blank cases.
4. For public intent, establish production-quality distinctive utility, truthful identity/listing metadata, icon and disclosures, current portal findings, skill safety scans, applicable review, approval, then the separate choice to Publish. Upload success is not final validation; see [submission errors](https://developers.openai.com/plugins/deploy/submission-errors) and [guidelines](https://developers.openai.com/plugins/plugin-guidelines). A teaching demo is not a proven eligible public product.

Security must be tested, not inferred from static checks. This source has no independent connector/storage/send capability, but that says nothing about host retention, other enabled tools, instruction following or injection resistance.

## Inventory and provenance

`rehearse.py`, `selftest.py`, ten host case specifications/fixtures, rubric, evidence template, fixture map, unchanged `source/` and unchanged old `runtime/` ZIP. Recorded final engineering results are included under `evidence/`. `provenance.json` records actual hashes/evidence labels. Do not upload this whole authoring kit as a plugin runtime ZIP.

Current research/citation comparison is supplied on the pool's research page and in its private source ledger; all documentation was checked 2026-10-01. That date is retrieval, not a release date. No authenticated workflow, account connection, purchase, protected-model workflow, plugin submission or publication was performed.
