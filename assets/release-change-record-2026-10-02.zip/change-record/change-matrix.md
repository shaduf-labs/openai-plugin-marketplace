# What changed for adopters? Four independently evidenced states

**Checked 2 October 2026.** Original maintenance synthesis, not an OpenAI schema or universal release validator. Source IDs C01–C10 in the companion record/Runner ledger refer to exact current primary URLs. All examples below are simulation-only; no existing Meeting Evidence release, listing or server was changed.

## Four-state model

| State | What this recorder can establish | Next independent evidence | Do not infer |
|---|---|---|---|
| **1 Source / runtime bundle** | OBSERVED_OFFLINE relative paths, bytes/hashes/fingerprint for two explicitly selected directories; narrow root name/version reading. | Reader-selected runtime scope, actual complete packaged release and its check if packaging is the task. | Completeness, schema validity, runtime compatibility, semantic correctness or components from names. |
| **2 Loaded host / session** | Actual result NOT RUN; loaded version/source/fingerprint UNKNOWN. Any declared version stays a declaration. | Actual client/version/surface, catalog source/ref, update/refresh/restart steps, fresh-session loaded provenance and actual task/retest. | Source edit or new ZIP automatically refreshed current sessions, or output proved activation/version. |
| **3 Reviewed / published version** | Actual result NOT RUN; review/public/version UNKNOWN. Any declared draft/approval stays a declaration. | Selected ZIP/version/checks, observed review/approval, separate Publish and directory version evidence. | Upload = approval; approval = Publish; pending review freezes code or proves current listing retention. |
| **4 Live remote MCP deployment** | Actual result NOT RUN; deployed code/endpoint/contracts UNKNOWN. Service/tool changes stay declarations. | Authorized deployment ID, actual endpoint behavior, live versus held definitions, scan completion/availability, current-contract/auth/permission regression. | Package fingerprint/version fixes backend implementation, tools or provider access. |

The boundaries in C01/C03/C04/C05/C09 are documented. The four lanes, evidence fields and conservative non-inferences are our original recording recommendations. No login, install, portal, publication, provider authorization or deployment was performed.

## Change / next-evidence matrix

**Status rule for every row:** only the explicit snapshot differences can be OBSERVED_OFFLINE. Channel, listing history, endpoints, review/deploy labels and tool/permission change descriptions are **READER DECLARATION**. Actual loaded/public/backend rows stay **UNKNOWN / NOT RUN**, including when declarations sound authoritative. Requirements below are documentary statements, not an observed acceptance decision; recommendations are ours.

| Before / declared context | Synthetic change and finite observation | Documented boundary | Our recommendation: next evidence | Do not infer |
|---|---|---|---|---|
| 0.1.0; intended public bundle | Skill bytes edited; root manifest untouched. Changed skill path, same version, unequal snapshot fingerprints. | Public bundled update path C03/C10; local cache/session C01/C09. | Choose a version deliberately (no automatic bump size), prepare complete bundle for intended public process; first verify actual compatible host loaded copy in fresh session and regress changed instruction. | Existing adopters received it, accepted version increment, or behavior improved. |
| Selected runtime files; intended bundle | Metadata wording or icon/resource bytes added/removed. Manifest/asset path differences only; no semantic validity claim. | C03 treats bundled metadata/assets/skills as package-version updates. | Inspect intended references, actual host asset/package compatibility and selected full ZIP; record public process separately if declared public. | A file group proves a valid icon, changed capabilities, policy eligibility or discovery. |
| 0.1.0 root fields | Only root version becomes 0.1.1; skill hashes stay equal. Tool verifies other parsed root fields equal; serialization may differ. | Optional portable version versus explicit public semantic version C02/C10. | Explain the release label and retest as appropriate; record source hash and actual loaded/public evidence. | Version bump alone means functional change, host update or approval. |
| 0.1.0 root fields | Payload changes with same version (the trap), or payload plus 0.1.1 change. Tool reports each independently. | C03/C10 governs public bundle updates; it does not specify our semantic bump choice. | Resolve version/content provenance before release notes; label what really changed and what is unobserved. | Equal version means equal payload or equal tools; unequal version establishes rollout. |
| Local/repo catalog selected; loaded copy unobserved | Source directory edited. Snapshot hash changes; loaded hash stays UNKNOWN. | C01 documents source resolution, cached install and desktop restart; C09 install/new session. | Identify exact catalog/root/ref and actual client; follow applicable source refresh/restart/new-session procedure, then record loaded evidence and behavior. | Source path was read directly, marketplace refresh is an install/activation test, or current sessions reloaded. |
| Public identity declared; existing published version unobserved | New complete ZIP uploaded/in-review is **only a declaration here**, not established by these directory hashes. | C03: new checks/review; replacement at Publish. C08 distinguishes approval and publishing. | Observe selected uploaded version, review/approval, actual Publish and resulting directory entry independently. | Upload/pending review replaced the listing, old package always stays available, access is continuous, or deployed code is frozen. |
| Package/declared endpoint unchanged | Context declares implementation/results change; identical selected source bytes. No deployment observation. | C05: contract-preserving server results can be live after deployment; retained tool metadata is not retained implementation. | Obtain deployment record and actual authorized behavior/current-contract regressions, separate from package record. | Same package/version means same results; a held metadata update shelters users from deployed code. |
| Tool contract/add/remove/auth/permission changes declared | Identical bundled files; context describes tool/permission delta, not inferred from hashes. | C04/C05: independent new/changed/deleted definitions and continuous checks; retain live-contract compatibility. | Observe live/held definition, completed scan/availability and actual current-contract/auth/permission behavior. | Every tool was held/approved together, removal takes effect at ZIP edit, changed scopes are authorized, or scan passed. |
| Stable endpoint declared | Context declares path move or origin move; recorder keeps category/URLs exactly as declarations. | **CONFLICT:** C07 unsupported URL flow/support versus C08 path/new version and origin/new identity. | Preserve production endpoint and get portal/support clarification tied to actual plugin identity before moving. | Recorder resolves conflicting docs, path move is accepted, new origin is authorized, or rollback/continuity is guaranteed. |
| Existing skills-only public listing declared | Proposed MCP addition declared; selected package may be identical. No history/component detection. | C06 public addition flow currently unsupported; architecture and public upgrade eligibility differ. | Resolve supported release/identity roadmap with actual portal/support evidence before promising adopters a connected upgrade. | Filename proves existing MCP, local component authoring grants a public upgrade path, or new release will retain access. |

Primary sources: [Packaging](https://developers.openai.com/plugins/build/plugins), [portable schema](https://agent-plugins.org/schemas/1.0.0/plugin.schema.json), [public submission/update](https://developers.openai.com/plugins/deploy/submission), [MCP review/maintenance](https://developers.openai.com/plugins/deploy/app-review), [user procedure](https://learn.chatgpt.com/docs/plugins). Checked 2026-10-02; not release dates.

## Trap → record → next evidence

Run the README command against `baseline` and `instruction-same-version`, with the explicit public simulation context. The model output is not involved. The finite result is:

```
added: []
removed: []
changed: [skills/meeting-evidence/SKILL.md]
unchanged: [plugin.json]
manifest version: 0.1.0 → 0.1.0
classification: CHANGED_BYTES_SAME_VERSION
loaded host/session: UNKNOWN, NOT RUN
reviewed/published version: UNKNOWN, NOT RUN
live backend deployment: UNKNOWN, NOT RUN
```

The corrected maintenance statement is **“The chosen skill bytes changed; adopter delivery is not established.”** Public simulation context makes C03/C10's complete versioned package path relevant; it does not make the teaching source publicly eligible. Local/repo context instead needs source/cache refresh and fresh-session evidence. Neither context performs any action. The blank companion worksheet asks for those observations; prior ten host records remain NOT RUN.
