#!/usr/bin/env python3
"""Offline byte inventory/change recorder. No plugin validation or host observations."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

UNKNOWN = "UNKNOWN"
SCHEMA = "https://agent-plugins.org/schemas/1.0.0/plugin.schema.json"
LIMITS = {"files": 1024, "entries": 4096, "depth": 32, "path_chars": 1024,
          "file_bytes": 8 * 1024 * 1024, "tree_bytes": 64 * 1024 * 1024,
          "context_bytes": 65536, "manifest_parse_bytes": 1024 * 1024}
RULES = {
    "C01": ("https://developers.openai.com/plugins/build/plugins", "source, cache, restart, portable/overlay boundaries"),
    "C02": (SCHEMA, "optional version; root identity reading is not schema validation"),
    "C03": ("https://developers.openai.com/plugins/deploy/submission", "public bundled update: complete versioned ZIP, checks, review, Publish"),
    "C04": ("https://developers.openai.com/plugins/deploy/submission", "MCP scan/held/live tool definition boundary"),
    "C05": ("https://developers.openai.com/plugins/deploy/app-review", "live deployed implementation is not frozen by held metadata"),
    "C06": ("https://developers.openai.com/plugins/deploy/submission", "MCP addition to an existing skills-only listing currently unsupported"),
    "C07": ("https://developers.openai.com/plugins/deploy/submission", "existing MCP URL update unsupported; contact support"),
    "C08": ("https://developers.openai.com/plugins/deploy/app-review", "path/new version versus origin/new plugin guidance conflicts with C07"),
    "C09": ("https://learn.chatgpt.com/docs/plugins", "supported install/new-session procedure; no version inspection method established here"),
    "C10": ("https://developers.openai.com/plugins/deploy/submission", "portable version optional; explicit semantic version for public submission/updates")
}


class InputError(Exception):
    def __init__(self, code, path, message):
        self.code, self.path, self.message = code, str(path), message


def fail(code, path, message):
    raise InputError(code, path, message)


def strict_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key: " + key)
            result[key] = value
        return result
    def constant(value):
        raise ValueError("non-JSON constant: " + value)
    return json.loads(data.decode("utf-8"), object_pairs_hook=pairs, parse_constant=constant)


def absolute_path(raw):
    path = Path(raw).expanduser()
    if ".." in path.parts:
        fail("INPUT_PATH_BOUNDARY", raw, "Parent traversal is outside recorder path policy.")
    return Path(os.path.abspath(path))


def check_components(path, leaf_may_be_missing=False):
    # Inspect without resolve(): a dangling symlink must not become a missing path.
    current = Path(path.anchor)
    for index, part in enumerate(path.parts[1:]):
        current = current / part
        try:
            mode = current.lstat().st_mode
        except FileNotFoundError:
            if leaf_may_be_missing and index == len(path.parts) - 2:
                return
            fail("INPUT_MISSING", current, "Path component does not exist.")
        if stat.S_ISLNK(mode):
            fail("INPUT_SYMLINK", current, "Input/output path symlinks are not followed.")
        if index != len(path.parts) - 2 and not stat.S_ISDIR(mode):
            fail("INPUT_NOT_DIRECTORY", current, "Ancestor must be a directory.")


def signature(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def read_fd_file(dirfd, name, rel, limit):
    old = os.stat(name, dir_fd=dirfd, follow_symlinks=False)
    if stat.S_ISLNK(old.st_mode):
        fail("INPUT_SYMLINK", rel, "Symlink file refused, including dangling symlinks.")
    if not stat.S_ISREG(old.st_mode):
        fail("INPUT_NOT_REGULAR", rel, "Only regular files can be inventoried.")
    if old.st_size > limit:
        fail("INPUT_RESOURCE_LIMIT", rel, "File byte limit exceeded (recorder policy).")
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=dirfd)
    try:
        start = os.fstat(fd)
        if not stat.S_ISREG(start.st_mode) or signature(start) != signature(old):
            fail("INPUT_CHANGED_DURING_READ", rel, "Input changed before reading; freeze the snapshot.")
        chunks, size = [], 0
        while True:
            block = os.read(fd, min(65536, limit + 1 - size))
            if not block:
                break
            chunks.append(block)
            size += len(block)
            if size > limit:
                fail("INPUT_RESOURCE_LIMIT", rel, "Read byte limit exceeded (recorder policy).")
        if signature(os.fstat(fd)) != signature(start) or signature(os.stat(name, dir_fd=dirfd, follow_symlinks=False)) != signature(start):
            fail("INPUT_CHANGED_DURING_READ", rel, "Input changed during reading; freeze the snapshot.")
        return b"".join(chunks)
    finally:
        os.close(fd)


def file_group(rel):
    if rel == "plugin.json":
        return "manifest"
    if rel.startswith("skills/"):
        return "skill"
    if rel.startswith("assets/"):
        return "asset"
    return "other_runtime_file"


def interpret_manifest(data):
    result = {"profile": "portable-root-plugin-json-identity-reading-v1", "status": "unsupported-for-manifest-interpretation",
              "name": UNKNOWN, "version": UNKNOWN, "issues": [],
              "effective_openai_metadata": "unsupported-for-manifest-interpretation",
              "components": UNKNOWN, "schema_validation": "NOT RUN"}
    if data is None:
        result["issues"] = ["MISSING_ROOT_MANIFEST"]
        return result
    if len(data) > LIMITS["manifest_parse_bytes"]:
        result["issues"] = ["MANIFEST_PARSE_LIMIT"]
        return result
    try:
        manifest = strict_json(data)
    except (ValueError, UnicodeError, RecursionError):
        result["issues"] = ["MALFORMED_MANIFEST_JSON_OR_UTF8"]
        return result
    if not isinstance(manifest, dict):
        result["issues"] = ["MANIFEST_NOT_OBJECT"]
        return result
    if manifest.get("$schema") != SCHEMA:
        result["issues"] = ["UNSUPPORTED_ROOT_SCHEMA"]
        return result
    result["status"] = "portable-root-fields-read-not-validated"
    for key in ("name", "version"):
        value = manifest.get(key)
        if isinstance(value, str) and value.strip() and len(value) <= 4096:
            result[key] = value
        else:
            result["issues"].append("UNKNOWN_" + key.upper())
    return result


def inventory(path):
    check_components(path)
    if not stat.S_ISDIR(path.lstat().st_mode):
        fail("INPUT_NOT_DIRECTORY", path, "Snapshot must be an explicit directory.")
    rows, counters, manifest_data = [], {"entries": 0, "bytes": 0}, None
    def walk(fd, prefix, depth):
        nonlocal manifest_data
        start = os.fstat(fd)
        if depth > LIMITS["depth"]:
            fail("INPUT_RESOURCE_LIMIT", prefix, "Directory depth limit exceeded.")
        for name in sorted(os.listdir(fd)):
            rel = prefix + name
            counters["entries"] += 1
            if counters["entries"] > LIMITS["entries"] or len(rel) > LIMITS["path_chars"]:
                fail("INPUT_RESOURCE_LIMIT", rel, "Entry count or path length limit exceeded.")
            try:
                rel.encode("utf-8")
            except UnicodeError:
                fail("INPUT_PATH_ENCODING", rel, "Paths must be UTF-8 representable.")
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                fail("INPUT_SYMLINK", rel, "Snapshot symlinks are not followed.")
            if stat.S_ISDIR(info.st_mode):
                child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                try:
                    if signature(os.fstat(child)) != signature(info):
                        fail("INPUT_CHANGED_DURING_READ", rel, "Directory changed before reading.")
                    walk(child, rel + "/", depth + 1)
                finally:
                    os.close(child)
            elif stat.S_ISREG(info.st_mode):
                if len(rows) >= LIMITS["files"] or counters["bytes"] + info.st_size > LIMITS["tree_bytes"]:
                    fail("INPUT_RESOURCE_LIMIT", rel, "File count or tree byte limit exceeded.")
                data = read_fd_file(fd, name, rel, LIMITS["file_bytes"])
                counters["bytes"] += len(data)
                rows.append({"path": rel, "group": file_group(rel), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
                if rel == "plugin.json":
                    manifest_data = data
            else:
                fail("INPUT_NOT_REGULAR", rel, "Special files refused; no device/FIFO reads.")
        if signature(os.fstat(fd)) != signature(start):
            fail("INPUT_CHANGED_DURING_READ", prefix, "Directory changed during reading.")
    root = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        walk(root, "", 0)
    finally:
        os.close(root)
    rows.sort(key=lambda row: row["path"])
    encoded = json.dumps([{k: row[k] for k in ("path", "bytes", "sha256")} for row in rows], sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("ascii")
    return {"status": "OBSERVED_OFFLINE", "input_path": str(path), "fingerprint": hashlib.sha256(encoded).hexdigest(),
            "fingerprint_method": "sha256(canonical ASCII JSON array of path/bytes/sha256; sorted paths; no mtimes or file modes)",
            "total_bytes": counters["bytes"], "files": rows, "manifest": interpret_manifest(manifest_data)}


CONTEXT_DEFAULTS = {
    "channel": UNKNOWN, "existing_public_listing_components": UNKNOWN, "proposed_mcp_addition": UNKNOWN,
    "simulation_only": UNKNOWN, "provenance_note": UNKNOWN,
    "declared_loaded_version": UNKNOWN, "declared_loaded_source": UNKNOWN,
    "declared_published_version": UNKNOWN, "declared_review_status": UNKNOWN, "declared_deployment_id": UNKNOWN,
    "service": {"endpoint_before": UNKNOWN, "endpoint_after": UNKNOWN, "endpoint_change": UNKNOWN,
                "implementation_change": UNKNOWN, "tool_contract_change": UNKNOWN, "tool_addition": UNKNOWN,
                "tool_removal": UNKNOWN, "permission_boundary_change": UNKNOWN}
}


def context_shape(data, path):
    if not isinstance(data, dict) or data.get("schema_version") != "1":
        fail("CONTEXT_SHAPE", path, "Context must be an object with schema_version = '1'.")
    extra = set(data) - set(CONTEXT_DEFAULTS) - {"schema_version"}
    if extra:
        fail("CONTEXT_SHAPE", path, "Unknown context fields: " + ", ".join(sorted(extra)))
    result = json.loads(json.dumps(CONTEXT_DEFAULTS))
    enums = {"channel": {"local_repository", "workspace", "public_directory", UNKNOWN},
             "existing_public_listing_components": {"skills_only", "with_mcp", "none", UNKNOWN}}
    booleans = {"proposed_mcp_addition", "simulation_only"}
    for key, value in data.items():
        if key == "schema_version":
            continue
        if key == "service":
            if not isinstance(value, dict) or set(value) - set(result["service"]):
                fail("CONTEXT_SHAPE", path, "service must contain only supported declaration keys.")
            for subkey, subvalue in value.items():
                valid = False
                if subkey == "endpoint_change":
                    valid = isinstance(subvalue, str) and subvalue in {"none", "path", "origin", "other", UNKNOWN}
                elif subkey.startswith("endpoint_"):
                    valid = isinstance(subvalue, str) and bool(subvalue.strip()) and len(subvalue) <= 2048
                else:
                    valid = type(subvalue) is bool or subvalue == UNKNOWN
                if not valid:
                    fail("CONTEXT_SHAPE", path, "Wrong service declaration type/value: " + subkey)
                result["service"][subkey] = subvalue
        else:
            if key in enums:
                valid = isinstance(value, str) and value in enums[key]
            elif key in booleans:
                valid = type(value) is bool or value == UNKNOWN
            else:
                valid = isinstance(value, str) and bool(value.strip()) and len(value) <= 2048
            if not valid:
                fail("CONTEXT_SHAPE", path, "Wrong declaration type/value: " + key)
            result[key] = value
    return result


def read_context(path):
    if path is None:
        return {"basis": "ABSENT_CONTEXT_UNKNOWN", "input_path": UNKNOWN, "sha256": UNKNOWN,
                "facts": json.loads(json.dumps(CONTEXT_DEFAULTS))}
    check_components(path)
    parent = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        data = read_fd_file(parent, path.name, path, LIMITS["context_bytes"])
    finally:
        os.close(parent)
    try:
        parsed = strict_json(data)
    except (ValueError, UnicodeError, RecursionError):
        fail("CONTEXT_JSON", path, "Context is not readable strict UTF-8 JSON.")
    return {"basis": "READER_DECLARATION_NOT_OBSERVATION", "input_path": str(path),
            "sha256": hashlib.sha256(data).hexdigest(), "facts": context_shape(parsed, path)}


def diff(before, after):
    old = {item["path"]: item for item in before["files"]}
    new = {item["path"]: item for item in after["files"]}
    result = {label: [] for label in ("added", "removed", "changed", "unchanged")}
    for path in sorted(set(old) | set(new)):
        label = "added" if path not in old else "removed" if path not in new else "unchanged" if old[path]["sha256"] == new[path]["sha256"] and old[path]["bytes"] == new[path]["bytes"] else "changed"
        result[label].append({"path": path, "group": (new.get(path) or old[path])["group"],
                              "before": old.get(path), "after": new.get(path)})
    return result


def classify(before, after, changes):
    old, new = before["manifest"]["version"], after["manifest"]["version"]
    version_relation = UNKNOWN if UNKNOWN in (old, new) else "same" if old == new else "different"
    old_name, new_name = before["manifest"]["name"], after["manifest"]["name"]
    identity_relation = UNKNOWN if UNKNOWN in (old_name, new_name) else "same" if old_name == new_name else "different"
    any_bytes = bool(changes["added"] or changes["removed"] or changes["changed"])
    # version-only means the strict parsed root objects differ ONLY in version.
    version_only = False
    old_raw = before.get("_manifest_object")
    new_raw = after.get("_manifest_object")
    if version_relation == "different" and not changes["added"] and not changes["removed"] and [item["path"] for item in changes["changed"]] == ["plugin.json"] and isinstance(old_raw, dict) and isinstance(new_raw, dict):
        version_only = {k: v for k, v in old_raw.items() if k != "version"} == {k: v for k, v in new_raw.items() if k != "version"}
    label = "IDENTICAL_SNAPSHOT_BYTES" if not any_bytes else "CHANGED_BYTES_SAME_VERSION" if version_relation == "same" else "VERSION_ONLY_ROOT_FIELD_EDIT" if version_only else "CHANGED_BYTES_AND_VERSION" if version_relation == "different" else "CHANGED_BYTES_VERSION_UNKNOWN"
    return {"label": label, "bytes_changed": any_bytes, "manifest_version_relation": version_relation,
            "manifest_identity_relation": identity_relation,
            "version_only_basis": "strict parsed root objects equal after removing version; exact changed path plugin.json only; not plugin semantic interpretation" if version_only else "NOT ESTABLISHED",
            "semantic_impact": UNKNOWN, "semantic_version_choice": "NOT PERFORMED", "propagation": UNKNOWN}


def notes(facts):
    out = [{"basis": "OUR_MAINTENANCE_RECOMMENDATION", "rule_ids": ["C01", "C09"],
            "text": "Record actual loaded source/version and fresh-session behavior separately; source hashes never establish a host result."}]
    if facts["channel"] == "public_directory":
        out.append({"basis": "SOURCE_LINKED_RECOMMENDATION_CONDITIONED_ON_DECLARED_CHANNEL", "rule_ids": ["C03", "C10"],
                    "text": "For intended bundled public updates, use the documented complete versioned ZIP/checks/review/Publish path. Choose the version yourself; this record is not an eligibility or submission-readiness verdict."})
    elif facts["channel"] == "local_repository":
        out.append({"basis": "SOURCE_LINKED_RECOMMENDATION_CONDITIONED_ON_DECLARED_CHANNEL", "rule_ids": ["C01", "C09"],
                    "text": "Update the explicitly chosen catalog source, follow documented refresh/restart/new-session steps for the actual client, then observe the loaded copy. No such action was run here."})
    elif facts["channel"] == "workspace":
        out.append({"basis": "OUR_MAINTENANCE_RECOMMENDATION", "rule_ids": ["C01"],
                    "text": "Record the authorized workspace/import/share update and its actual saved result separately; this tool does not establish sync, access continuity, or installation."})
    else:
        out.append({"basis": "OUR_MAINTENANCE_RECOMMENDATION", "rule_ids": [], "text": "Channel UNKNOWN: select and document the intended distribution channel before choosing its next steps."})
    if any(facts["service"][key] is True for key in ("implementation_change", "tool_contract_change", "tool_addition", "tool_removal", "permission_boundary_change")):
        out.append({"basis": "SOURCE_LINKED_RECOMMENDATION_CONDITIONED_ON_READER_DECLARATION", "rule_ids": ["C04", "C05"],
                    "text": "Declared service/tool changes need independent deployment, live-contract, scan/availability and authorized behavior evidence. Hash equality says nothing about service behavior or review outcome."})
    if facts["service"]["endpoint_change"] in ("path", "origin", "other"):
        out.append({"basis": "CONFLICTING_DOCUMENTATION_NEXT_EVIDENCE", "rule_ids": ["C07", "C08"],
                    "text": "Endpoint move is reader-declared only. Conflicting update guidance remains unresolved; preserve the production endpoint and obtain portal/support clarification before moving it."})
    if facts["proposed_mcp_addition"] is True and facts["existing_public_listing_components"] == "skills_only":
        out.append({"basis": "SOURCE_LINKED_RECOMMENDATION_CONDITIONED_ON_READER_DECLARATION", "rule_ids": ["C06"],
                    "text": "Declared MCP addition to an existing skills-only listing: the documented flow is currently unsupported. Confirm a supported release/identity path; this is not detected from files or a portal test."})
    return out


def attach_root_object(snapshot, path):
    # Use already inventoried bytes in a no-follow second read, and require parity.
    row = next((item for item in snapshot["files"] if item["path"] == "plugin.json"), None)
    if row is None or row["bytes"] > LIMITS["manifest_parse_bytes"]:
        return
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        data = read_fd_file(fd, "plugin.json", "plugin.json", LIMITS["manifest_parse_bytes"])
    finally:
        os.close(fd)
    if hashlib.sha256(data).hexdigest() != row["sha256"]:
        fail("INPUT_CHANGED_DURING_READ", "plugin.json", "Manifest changed between reads.")
    try:
        snapshot["_manifest_object"] = strict_json(data)
    except (ValueError, UnicodeError, RecursionError):
        pass


def make_record(before_path, after_path, context_path):
    before, after = inventory(before_path), inventory(after_path)
    attach_root_object(before, before_path)
    attach_root_object(after, after_path)
    context = read_context(context_path)
    changes = diff(before, after)
    classification = classify(before, after, changes)
    before.pop("_manifest_object", None)
    after.pop("_manifest_object", None)
    facts = context["facts"]
    return {"schema_version": "1", "tool": "release-change-record-v1", "evidence_kind": "OFFLINE_ENGINEERING_ONLY",
            "scope": "Explicit reader-selected runtime-source regular-file snapshot bytes, root portable identity/version, and reader declarations only.",
            "exclusions": ["whole-repository/runtime selection inference", "archive extraction or creation", "complete plugin/schema validation", "effective overlay/extension metadata", "component/service detection", "semantic diff or automatic version choice", "secret/safety scanning", "host installation/update/invocation", "portal/review/approval/publication", "network/deployment/authorization"],
            "recorder_policy_limits": LIMITS, "context": context,
            "source_rules": [{"id": key, "url": value[0], "scope": value[1], "checked_utc": "2026-10-02"} for key, value in RULES.items()],
            "states": {
                "source_bundle": {"basis": "OBSERVED_OFFLINE", "before": before, "after": after, "diff": changes,
                                  "classification": classification, "loaded_or_published_fingerprint": UNKNOWN},
                "loaded_host_session": {"actual_test_status": "NOT RUN", "observed_version": UNKNOWN, "observed_source": UNKNOWN, "observed_fingerprint": UNKNOWN, "session_evidence": UNKNOWN,
                                        "declarations": {key: facts[key] for key in ("declared_loaded_version", "declared_loaded_source")}},
                "reviewed_published_version": {"actual_test_status": "NOT RUN", "observed_review_status": UNKNOWN, "observed_published_version": UNKNOWN, "observed_directory_fingerprint": UNKNOWN, "publication_evidence": UNKNOWN,
                                               "declarations": {key: facts[key] for key in ("declared_published_version", "declared_review_status")}},
                "live_backend_deployment": {"actual_test_status": "NOT RUN", "observed_deployment_id": UNKNOWN, "observed_endpoint": UNKNOWN, "observed_contract": UNKNOWN, "authorized_behavior_evidence": UNKNOWN,
                                            "declarations": {"declared_deployment_id": facts["declared_deployment_id"], "service": facts["service"]}}
            }, "next_evidence": notes(facts),
            "unknowns": ["selected snapshots' completeness as intended runtime", "semantic correctness and impact", "effective components/settings", "actual installed/loaded version and current-session refresh", "actual public version/review/approval", "actual deployed code/tools/auth/permissions", "adopter access, propagation, review timing and rollback capability"]}


def readable(record):
    state = record["states"]["source_bundle"]
    lines = ["# Release change record", "", "OFFLINE ENGINEERING ONLY — not a runtime submission ZIP or plugin validator.",
             "Source rules checked: 2026-10-02 (retrieval date, not a release date).", "",
             "## 1. Source / bundle: OBSERVED_OFFLINE", "Classification: " + state["classification"]["label"],
             "Manifest version relation: " + state["classification"]["manifest_version_relation"]]
    for label in ("before", "after"):
        snap = state[label]
        lines += ["", label + " input: " + json.dumps(snap["input_path"]), label + " snapshot fingerprint: " + snap["fingerprint"],
                  label + " root manifest: " + json.dumps(snap["manifest"], sort_keys=True)]
    for label, rows in state["diff"].items():
        lines += ["", label.upper() + " (" + str(len(rows)) + "):"]
        lines += ["- " + json.dumps(row["path"]) + " [" + row["group"] + "]" for row in rows] or ["- none"]
    lines += ["", "Fingerprints describe chosen file bytes/paths, not manifest release versions or installed/published copies.",
              "File groups are coarse inventory aids, not component detection or policy/semantic conclusions.",
              "", "## Reader context: " + record["context"]["basis"], json.dumps(record["context"], indent=2, sort_keys=True),
              "", "## 2. Loaded host/session: NOT RUN; actual version/source/fingerprint UNKNOWN", "## 3. Reviewed/published version: NOT RUN; actual version/review/publication UNKNOWN", "## 4. Live backend deployment: NOT RUN; actual deployment/endpoint/contract UNKNOWN",
              "Reader declarations NEVER replace these actual fields.", "", "## Next evidence / recommendations"]
    for note in record["next_evidence"]:
        lines.append("- " + note["basis"] + " [" + ", ".join(note["rule_ids"]) + "]: " + note["text"])
    lines += ["", "## Current source references"]
    lines += ["- " + rule["id"] + ": " + rule["url"] + " — " + rule["scope"] for rule in record["source_rules"]]
    lines += ["", "## Unknowns", *["- " + value for value in record["unknowns"]], "", "## Exclusions", *["- " + value for value in record["exclusions"]], "", "Recorder limits (our policy, not platform rules): " + json.dumps(LIMITS, sort_keys=True)]
    return "\n".join(lines) + "\n"


def output_guard(out, inputs):
    # One new output directory owns both destinations; no record/log collision.
    for source in inputs:
        if source is not None and (out == source or source in out.parents):
            fail("OUTPUT_INSIDE_INPUT", out, "Output must be outside every input tree/file.")
    if os.path.lexists(out):
        fail("OUTPUT_EXISTS", out, "Never replace an existing record, directory, or dangling symlink.")
    check_components(out, leaf_may_be_missing=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", required=True)
    parser.add_argument("--after", required=True)
    parser.add_argument("--context", help="Optional strict JSON of reader declarations, not observations")
    parser.add_argument("--out", required=True, help="New record directory outside inputs; parent must exist")
    args = parser.parse_args()
    out = None
    created = False
    try:
        if os.name != "posix" or not all(hasattr(os, key) for key in ("O_NOFOLLOW", "O_DIRECTORY")):
            fail("UNSUPPORTED_READER_PLATFORM", "platform", "Requires POSIX no-follow directory/file reading.")
        before, after = absolute_path(args.before), absolute_path(args.after)
        context = absolute_path(args.context) if args.context else None
        out = absolute_path(args.out)
        output_guard(out, [before, after, context])
        record = make_record(before, after, context)
        # Atomic exclusive directory reservation; output is never silently replaced.
        os.mkdir(out, 0o700)
        created = True
        (out / "record.json").write_text(json.dumps(record, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")
        (out / "record.md").write_text(readable(record), encoding="utf-8")
        print(json.dumps({"status": "RECORDED_OFFLINE_NOT_VALIDATED", "classification": record["states"]["source_bundle"]["classification"]["label"], "output": str(out)}, sort_keys=True))
        return 0
    except InputError as exc:
        print(json.dumps({"status": "RECORDER_INPUT_ERROR_NOT_PLATFORM_VIOLATION", "code": exc.code, "path": exc.path, "message": exc.message}, sort_keys=True))
        return 2
    except OSError as exc:
        print(json.dumps({"status": "RECORDER_IO_ERROR_NOT_PLATFORM_VIOLATION", "code": "IO_ERROR", "path": str(exc.filename), "message": str(exc)}, sort_keys=True))
        return 2
    finally:
        # Partial I/O output is retained explicitly, never deleted/replaced silently.
        if created and out is not None and not (out / "record.md").exists():
            print("Partial output directory retained after I/O failure: " + str(out), file=sys.stderr)


if __name__ == "__main__":
    sys.exit(main())
