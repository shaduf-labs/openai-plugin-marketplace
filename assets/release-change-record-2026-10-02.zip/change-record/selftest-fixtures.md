# Synthetic fixtures / exact expectations

Every revision/context is **simulation-only**, not an actual Meeting Evidence version, listing or MCP service. Baseline copies only the two assigned immutable runtime files. New instruction line is an intentionally simple byte mutation, not tested model behavior.

All successful cases require exit 0; exact inventory/diff rows (path, group, bytes, SHA-256), classification/version relation, parsed-interpretation issues, context defaults/declarations, all three unobserved state sets and independent fingerprint computation are checked. All actual host/public/backend status fields remain NOT RUN, with observed fields UNKNOWN. `selftest.py` contains exact expectations; final logs include full actual JSON and expected/actual comparisons.

| Case | Change / context | Exact different paths | Classification / interpretation |
|---|---|---|---|
| S01 | Identical baseline; local context | none | IDENTICAL_SNAPSHOT_BYTES; same version |
| S02 | Append instruction; public context | changed skills/meeting-evidence/SKILL.md; unchanged plugin.json | CHANGED_BYTES_SAME_VERSION |
| S03 | Append instruction plus 0.1.1 | changed plugin.json + skill | CHANGED_BYTES_AND_VERSION |
| S04 | Only parsed version 0.1.1; reserialized root | changed plugin.json; unchanged skill | VERSION_ONLY_ROOT_FIELD_EDIT |
| S05 | Add assets/simulation-note.txt | added resource; two baseline paths unchanged | CHANGED_BYTES_SAME_VERSION |
| S06 | Remove that resource | removed resource; two baseline paths unchanged | CHANGED_BYTES_SAME_VERSION |
| S07 | Declare service deploy/change/versions/approval | none | IDENTICAL_SNAPSHOT_BYTES; all declared strings stay declarations |
| S08 | Declare endpoint path move | none | IDENTICAL_SNAPSHOT_BYTES; conflict note C07/C08 |
| S09 | Declare origin move | none | IDENTICAL_SNAPSHOT_BYTES; conflict note C07/C08 |
| S10 | Declare MCP addition to skills-only public listing | none | IDENTICAL_SNAPSHOT_BYTES; source-linked declaration note C06, not verdict |
| S11 | Compatibility-only layout; no context | none; inventory .codex-plugin/plugin.json + skill | IDENTICAL_SNAPSHOT_BYTES; versions UNKNOWN, MISSING_ROOT_MANIFEST |
| S12 | Root description edit | changed plugin.json | CHANGED_BYTES_SAME_VERSION |
| S13 | Declare contract/add/remove/permission changes | none | IDENTICAL_SNAPSHOT_BYTES; no component/deploy inference |
| S14 | Remove optional root version; no context | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; UNKNOWN_VERSION |
| S15 | Add mcp.json containing arbitrary synthetic bytes | added mcp.json; two baseline files unchanged | CHANGED_BYTES_SAME_VERSION; components/context UNKNOWN, group other_runtime_file |
| S16 | Invalid JSON root | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; MALFORMED_MANIFEST_JSON_OR_UTF8 |
| S17 | Null root | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; MANIFEST_NOT_OBJECT |
| S18 | Duplicate root keys | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; MALFORMED_MANIFEST_JSON_OR_UTF8 |
| S19 | Invalid UTF-8 root | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; MALFORMED_MANIFEST_JSON_OR_UTF8 |
| S20 | Unsupported schema | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; UNSUPPORTED_ROOT_SCHEMA |
| S21 | Numeric name / boolean version | changed plugin.json | CHANGED_BYTES_VERSION_UNKNOWN; UNKNOWN_NAME + UNKNOWN_VERSION |

R01 repeats S02 with a second output directory. I01 compares both record.json and record.md bytes; expected identical because output destination and wall-clock time are not record inputs.

## Boundary checks (all exact exit 2 and own expected code)

E01 malformed context / E21 duplicate context → CONTEXT_JSON.
E02 null context, E03 unsupported channel, E04 fake actual status field, E22 bad service flag → CONTEXT_SHAPE.
E05 missing input / E26 missing output parent → INPUT_MISSING.
E06 file snapshot → INPUT_NOT_DIRECTORY.
E07 file symlink, E08 directory symlink, E09 dangling input, E10 root symlink, E11 ancestor symlink, E12 context symlink, E16 output parent symlink → INPUT_SYMLINK.
E13 output inside input → OUTPUT_INSIDE_INPUT.
E14 existing record, E15 dangling output link, E17 existing output file → OUTPUT_EXISTS.
E18 parent traversal → INPUT_PATH_BOUNDARY.
E19 FIFO → INPUT_NOT_REGULAR (no FIFO open/read).
E20 file 8 MiB+1, E23 depth 33, E24 1025 files, E25 context 65537 bytes → INPUT_RESOURCE_LIMIT.

These are **recorder policy tests**, not inferred OpenAI package rules. Their exact expected codes are required; a different error does not pass. One new output directory owns both record files, so callers cannot request colliding record destinations. Test output/input-tree preservation is also checked. Future host/platform/semantic/security tests remain outside scope and NOT RUN.
