# Release change record — offline tooling, not a runtime submission ZIP

Checked 2 October 2026. This download is **tooling with simulation-only fixtures**. It is not a new Meeting Evidence release, an installable production plugin or a complete validator. It runs offline without login, network, API key, dependencies or service access. No install/deploy/submit/catalog mutation, archive extraction or archive creation is performed by `record.py`.

## Run the concrete trap

Requirements: Python 3.8+ on POSIX with no-follow file/directory support (tested Python 3.11.2 on this Linux environment). Windows is unsupported by this reader; it receives a recorder-platform error, not invalid-plugin advice. Extract this *tooling download* into scratch; enter `change-record/`, then run:

```sh
python3 record.py --before fixtures/snapshots/baseline \
  --after fixtures/snapshots/instruction-same-version \
  --context fixtures/contexts/public.json --out my-change-record
python3 selftest.py
```

The parent of `--out` must exist and `my-change-record` must not exist. To repeat, choose a new output directory; never overwrite a previous record. Both a readable `record.md` and a machine `record.json` are written into that one new directory. This single output design prevents two record destinations colliding. Exit **0 = offline record written, NOT plugin validated**; **2 = recorder input/CLI/I/O/platform error, NOT platform violation**. A malformed manifest is still inventoried and can exit 0 with UNKNOWN/unsupported manifest interpretation.

The baseline has only the immutable assigned 0.1.0 runtime files. The after fixture appends one simulation-only instruction line, leaving `plugin.json` unchanged. Expect changed `skills/meeting-evidence/SKILL.md`, unchanged `plugin.json`, no additions/removals, `CHANGED_BYTES_SAME_VERSION`, and both manifest versions `0.1.0`. Host/session, public version and live backend observations stay UNKNOWN; all their actual test statuses stay NOT RUN even if context declares versions/review/deployment.

For actual work, make **explicit reader-selected intended-runtime snapshot directories** and substitute their paths. Do not point at the whole repo and assume every inventoried file should ship. The tool hashes every regular file inside the selected trees, including hidden files; it has no packaging allowlist, ignore file, secret scan or automatic runtime selector.

## What is—and is not—observed

- Added/removed/changed/unchanged relative paths, byte sizes and SHA-256s; coarse `manifest` (root plugin.json), `skill` (skills/), `asset` (assets/) and `other_runtime_file` groups are inventory aids, never component or semantic/policy detection.
- Snapshot fingerprint: SHA-256 of canonical ASCII JSON `[path, bytes, sha256]` row objects, sorted by path. It includes file paths/content, not absolute input locations, mtime, modes, empty directories or context. An unchanged manifest version does not mean unchanged fingerprint; equal fingerprints do not freeze deployed tools. No installed/published fingerprint is inferred.
- Supported reading profile: **portable root `plugin.json`** declaring the exact Agent Plugins 1.0.0 schema. Only nonempty string name/version are read, not validated. Missing/wrong-type fields are UNKNOWN; missing/malformed root or other schemas/layouts are unsupported-for-manifest-interpretation. Compatibility-only manifests are not universally invalid. Effective overlay/inline OpenAI metadata is always unsupported-for-manifest-interpretation, and components stay UNKNOWN. No filename becomes proof of an MCP integration.
- `VERSION_ONLY_ROOT_FIELD_EDIT` requires only plugin.json changed, known unequal versions, and parsed root objects equal after removing version. Serialization differences may also exist. This implements a narrow root-field comparison, **not plugin semantic correctness or a full semantic diff**. Other labels: IDENTICAL_SNAPSHOT_BYTES, CHANGED_BYTES_SAME_VERSION, CHANGED_BYTES_AND_VERSION, CHANGED_BYTES_VERSION_UNKNOWN. Version choices are never automated.
- Four separate sections: observed source/bundle snapshots; loaded host/session; reviewed/published version; live backend deployment. The last three actual test statuses are always NOT RUN and actual fields always UNKNOWN. Declared facts are nested separately; even a declared "approved" status is not observed approval.
- Dated source-rule IDs C01–C10 and conditional next-evidence recommendations, not a rules engine, eligibility verdict, safety result or submission-ready flag. Docs require public versioned bundles; our tool never selects patch/minor/major or certifies policy acceptance.

## Optional context shape — declarations only

Omitting `--context` leaves every fact UNKNOWN. `context-example.json` is a blank supported shape. `schema_version` must be string `1`; omitted supported fields default UNKNOWN. Unknown keys, wrong types, duplicate JSON keys, non-JSON constants or malformed UTF-8/JSON are recorder input errors. Null is not an UNKNOWN value.

- `channel`: local_repository, workspace, public_directory or UNKNOWN.
- `existing_public_listing_components`: skills_only, with_mcp, none or UNKNOWN. These are declarations of listing history, not file detection.
- `proposed_mcp_addition` and `simulation_only`: boolean or UNKNOWN.
- `provenance_note`, declared_loaded_version/source, declared_published_version/review_status/deployment_id: nonempty string, at most 2048 characters. They are public-safe context labels, not evidence imports.
- `service`: supported endpoint_before/after strings (at most 2048 characters); endpoint_change = none, path, origin, other or UNKNOWN; implementation_change, tool_contract_change, tool_addition, tool_removal and permission_boundary_change = boolean or UNKNOWN. Endpoints and movement category are expressly declared, not inferred/connected/fetched. Never include tokens, keys or credentials.

`next-evidence-worksheet.json` is a **separate blank manual worksheet**, not valid recorder context. It prompts a future authorized tester for actual loaded source/session evidence, directory/review/publish evidence, and deployment/live-contract checks. It does not overwrite or complete the previous kit's ten NOT RUN host cases.

## Safe-reading / output policy (ours, not OpenAI rules)

Do not follow any snapshot/context/root/ancestor symlink, including dangling links. Do not read devices/FIFOs/sockets; only regular files. Inspect sorted directories and use no-follow descriptor-relative reading. Refuse parent-traversal (`..`) arguments, non-UTF-8-representable paths and changed-during-read inputs. **Freeze snapshots and avoid concurrent/adversarial filesystem mutation**; this is not an adversarial filesystem sandbox or a secret/safety scanner. OS read permissions must be available.

Limits: 1024 regular files, 4096 entries, depth 32, 1024 relative-path characters, 8 MiB/file, 64 MiB/tree, 64 KiB context and 1 MiB manifest parsing. A larger manifest can still be hashed if within inventory limits, but its reading is unsupported. Limits are deliberate recorder resource policy, not package requirements. Snapshot trees are never written. `--out` is refused inside inputs, through symlink parents or when already present (including a dangling symlink). Exclusive directory creation refuses a concurrent output reservation. Partial output on an I/O failure is explicitly retained and reported, not silently replaced.

## Exact self-test evidence

`python3 selftest.py` uses independent temporary scratch and reads included fixtures. Optional `--evidence /existing/parent/new-evidence` writes exact command/output/expectation logs and machine summary to a **new directory outside this tooling folder**. Existing evidence is refused. This is engineering coverage, not plugin quality, propagation or platform acceptance.

Final exercised run: 21 exact synthetic scenario commands + 1 repeat + 26 input/output-boundary commands = **48 subprocess commands**. One JSON/Markdown deterministic-byte invariant gives **49 passed engineering assertions**, zero failures. `selftest-fixtures.md` lists mutations and exact paths/labels; `evidence/validation.log` and summary contain exact commands, expected/actual exits, hashes, groups, classifications, contexts and full actual records. Negative tests require the expected code, not just any failure.

The final download was independently extracted into scratch, every provenance payload verified, and both commands above rerun. Private reproduction receipt lives outside the ZIP; publication/delivery receipts are Runtime's, not this tooling evidence.

## Sources and further reading

The original four-state model and `change-matrix.md` distinguish documented requirements, recommendations, offline facts, reader declarations and future evidence. Primary sources checked 2 October: [Packaging](https://developers.openai.com/plugins/build/plugins), [portable manifest schema](https://agent-plugins.org/schemas/1.0.0/plugin.schema.json), [public submission/update](https://developers.openai.com/plugins/deploy/submission), [MCP maintenance](https://developers.openai.com/plugins/deploy/app-review), [supported user procedure](https://learn.chatgpt.com/docs/plugins). Endpoint URL-change guidance conflicts: no precedence or portal result is guessed. Version replacement at Publish is documented; retention during all pending reviews is not directly established here. Previous migration/catalog/prices/annotation check dates and all previous host records remain unchanged.
