#!/usr/bin/env python3
"""Exact synthetic recorder regressions, not plugin/platform tests."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).absolute().parent
SNAP = HERE / "fixtures/snapshots"
CTX = HERE / "fixtures/contexts"
BASE = ["plugin.json", "skills/meeting-evidence/SKILL.md"]
SKILL = "skills/meeting-evidence/SKILL.md"
SCENARIOS = [
    ("S01_identical", "baseline", "baseline", "local", [], [], [], BASE, "IDENTICAL_SNAPSHOT_BYTES", "same", []),
    ("S02_instruction_same_version", "baseline", "instruction-same-version", "public", [], [], [SKILL], ["plugin.json"], "CHANGED_BYTES_SAME_VERSION", "same", []),
    ("S03_instruction_and_version", "baseline", "instruction-and-version", "public", [], [], BASE, [], "CHANGED_BYTES_AND_VERSION", "different", []),
    ("S04_version_only", "baseline", "version-only", "local", [], [], ["plugin.json"], [SKILL], "VERSION_ONLY_ROOT_FIELD_EDIT", "different", []),
    ("S05_asset_addition", "baseline", "asset-added", "public", ["assets/simulation-note.txt"], [], [], BASE, "CHANGED_BYTES_SAME_VERSION", "same", []),
    ("S06_asset_removal", "asset-added", "baseline", "public", [], ["assets/simulation-note.txt"], [], BASE, "CHANGED_BYTES_SAME_VERSION", "same", []),
    ("S07_declared_service_only", "baseline", "baseline", "service-only", [], [], [], BASE, "IDENTICAL_SNAPSHOT_BYTES", "same", []),
    ("S08_declared_endpoint_path", "baseline", "baseline", "endpoint-path", [], [], [], BASE, "IDENTICAL_SNAPSHOT_BYTES", "same", []),
    ("S09_declared_endpoint_origin", "baseline", "baseline", "endpoint-origin", [], [], [], BASE, "IDENTICAL_SNAPSHOT_BYTES", "same", []),
    ("S10_declared_mcp_addition", "baseline", "baseline", "mcp-addition", [], [], [], BASE, "IDENTICAL_SNAPSHOT_BYTES", "same", []),
    ("S11_no_context_compatibility_only", "compatibility-only", "compatibility-only", None, [], [], [], [".codex-plugin/plugin.json", SKILL], "IDENTICAL_SNAPSHOT_BYTES", "UNKNOWN", ["MISSING_ROOT_MANIFEST"]),
    ("S12_metadata_wording", "baseline", "metadata-edit", "local", [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_SAME_VERSION", "same", []),
    ("S13_declared_tool_permission_boundaries", "baseline", "baseline", "tool-boundaries", [], [], [], BASE, "IDENTICAL_SNAPSHOT_BYTES", "same", []),
    ("S14_optional_version_absent", "baseline", "missing-version", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["UNKNOWN_VERSION"]),
    ("S15_filename_not_component", "baseline", "filename-not-component", None, ["mcp.json"], [], [], BASE, "CHANGED_BYTES_SAME_VERSION", "same", []),
    ("S16_malformed_manifest", "baseline", "malformed-manifest", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["MALFORMED_MANIFEST_JSON_OR_UTF8"]),
    ("S17_nonobject_manifest", "baseline", "nonobject-manifest", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["MANIFEST_NOT_OBJECT"]),
    ("S18_duplicate_manifest_keys", "baseline", "duplicate-manifest", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["MALFORMED_MANIFEST_JSON_OR_UTF8"]),
    ("S19_invalid_utf8_manifest", "baseline", "invalid-utf8-manifest", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["MALFORMED_MANIFEST_JSON_OR_UTF8"]),
    ("S20_unsupported_schema", "baseline", "unsupported-schema", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["UNSUPPORTED_ROOT_SCHEMA"]),
    ("S21_wrong_root_field_types", "baseline", "wrong-field-types", None, [], [], ["plugin.json"], [SKILL], "CHANGED_BYTES_VERSION_UNKNOWN", "UNKNOWN", ["UNKNOWN_NAME", "UNKNOWN_VERSION"])
]


def expected_inventory(root, paths):
    rows = []
    for rel in sorted(paths):
        data = (root / rel).read_bytes()
        group = "manifest" if rel == "plugin.json" else "skill" if rel.startswith("skills/") else "asset" if rel.startswith("assets/") else "other_runtime_file"
        rows.append({"path": rel, "group": group, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    return rows


def expected_context(path):
    result = {"channel": "UNKNOWN", "existing_public_listing_components": "UNKNOWN", "proposed_mcp_addition": "UNKNOWN", "simulation_only": "UNKNOWN", "provenance_note": "UNKNOWN",
              "declared_loaded_version": "UNKNOWN", "declared_loaded_source": "UNKNOWN", "declared_published_version": "UNKNOWN", "declared_review_status": "UNKNOWN", "declared_deployment_id": "UNKNOWN",
              "service": {"endpoint_before": "UNKNOWN", "endpoint_after": "UNKNOWN", "endpoint_change": "UNKNOWN", "implementation_change": "UNKNOWN", "tool_contract_change": "UNKNOWN", "tool_addition": "UNKNOWN", "tool_removal": "UNKNOWN", "permission_boundary_change": "UNKNOWN"}}
    if path:
        for key, value in json.loads(path.read_text()).items():
            if key == "schema_version":
                continue
            if key == "service":
                result[key].update(value)
            else:
                result[key] = value
    return result


def check_record(record, scenario, out):
    _, before_name, after_name, context_name, added, removed, changed, unchanged, label, version, issues = scenario
    old_paths, new_paths = sorted(removed + changed + unchanged), sorted(added + changed + unchanged)
    state = record["states"]["source_bundle"]
    before, after = SNAP / before_name, SNAP / after_name
    context = CTX / (context_name + ".json") if context_name else None
    expected = {"diff": {"added": sorted(added), "removed": sorted(removed), "changed": sorted(changed), "unchanged": sorted(unchanged)},
                "classification": label, "version_relation": version, "manifest_issues_after": issues,
                "before_inventory": expected_inventory(before, old_paths), "after_inventory": expected_inventory(after, new_paths),
                "context_facts": expected_context(context), "actual_test_status": "NOT RUN", "actual_fields": "UNKNOWN"}
    actual = {"diff": {key: [row["path"] for row in state["diff"][key]] for key in expected["diff"]},
              "classification": state["classification"]["label"], "version_relation": state["classification"]["manifest_version_relation"],
              "manifest_issues_after": state["after"]["manifest"]["issues"], "before_inventory": state["before"]["files"], "after_inventory": state["after"]["files"],
              "context_facts": record["context"]["facts"], "actual_test_status": "NOT RUN", "actual_fields": "UNKNOWN"}
    assert actual == expected, "Exact inventory/classification/context mismatch"
    old_rows = {row["path"]: row for row in expected["before_inventory"]}
    new_rows = {row["path"]: row for row in expected["after_inventory"]}
    expected_diff_rows = {label: [{"path": path, "group": (new_rows.get(path) or old_rows[path])["group"], "before": old_rows.get(path), "after": new_rows.get(path)} for path in paths] for label, paths in expected["diff"].items()}
    assert state["diff"] == expected_diff_rows, "Wrong exact diff row hashes/byte counts/groups"
    for side in ("before", "after"):
        rows = state[side]["files"]
        canonical = json.dumps([{key: row[key] for key in ("path", "bytes", "sha256")} for row in rows], sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("ascii")
        assert state[side]["fingerprint"] == hashlib.sha256(canonical).hexdigest(), "Wrong deterministic fingerprint"
        assert state[side]["manifest"]["components"] == "UNKNOWN"
        assert state[side]["manifest"]["effective_openai_metadata"] == "unsupported-for-manifest-interpretation"
        assert state[side]["manifest"]["schema_validation"] == "NOT RUN"
    for key in ("loaded_host_session", "reviewed_published_version", "live_backend_deployment"):
        other = record["states"][key]
        assert other["actual_test_status"] == "NOT RUN", "Declaration became actual status"
        for field, value in other.items():
            if field != "declarations" and field != "actual_test_status":
                assert value == "UNKNOWN", "Declaration became observation: " + field
    assert state["loaded_or_published_fingerprint"] == "UNKNOWN"
    expected_identity = "UNKNOWN" if scenario[1] == "compatibility-only" or scenario[2] in ("compatibility-only", "malformed-manifest", "nonobject-manifest", "duplicate-manifest", "invalid-utf8-manifest", "unsupported-schema", "wrong-field-types") else "same"
    assert state["classification"]["manifest_identity_relation"] == expected_identity
    assert state["classification"]["semantic_impact"] == "UNKNOWN"
    assert state["classification"]["semantic_version_choice"] == "NOT PERFORMED"
    assert state["classification"]["propagation"] == "UNKNOWN"
    assert record["context"]["basis"] == ("READER_DECLARATION_NOT_OBSERVATION" if context else "ABSENT_CONTEXT_UNKNOWN")
    if context:
        assert record["context"]["sha256"] == hashlib.sha256(context.read_bytes()).hexdigest()
    expected_note_ids = [["C01", "C09"]]
    if context_name in ("public", "service-only", "endpoint-path", "endpoint-origin", "mcp-addition", "tool-boundaries"):
        expected_note_ids.append(["C03", "C10"])
    elif context_name == "local":
        expected_note_ids.append(["C01", "C09"])
    else:
        expected_note_ids.append([])
    if context_name in ("service-only", "tool-boundaries"):
        expected_note_ids.append(["C04", "C05"])
    if context_name in ("endpoint-path", "endpoint-origin"):
        expected_note_ids.append(["C07", "C08"])
    if context_name == "mcp-addition":
        expected_note_ids.append(["C06"])
    assert [note["rule_ids"] for note in record["next_evidence"]] == expected_note_ids, "Wrong conditional next-evidence source references"
    expected["next_evidence_rule_ids"] = expected_note_ids
    actual["next_evidence_rule_ids"] = [note["rule_ids"] for note in record["next_evidence"]]
    assert (out / "record.md").is_file()
    assert "Reader declarations NEVER replace these actual fields." in (out / "record.md").read_text()
    return expected, actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", help="Optional NEW evidence directory outside this tooling folder")
    args = parser.parse_args()
    evidence = None
    if args.evidence:
        evidence = Path(os.path.abspath(args.evidence))
        if os.path.lexists(evidence) or evidence == HERE or HERE in evidence.parents or not evidence.parent.is_dir() or any(p.is_symlink() for p in [evidence.parent, *evidence.parent.parents]):
            parser.error("evidence must be a new directory with real existing parents outside tooling; no overwrite")
    results, log, invariants = [], [], []
    with tempfile.TemporaryDirectory(prefix="release-change-selftest-") as scratch:
        work = Path(scratch)
        def run(identifier, command, expect_exit, expect_code=None, scenario=None):
            proc = subprocess.run(command, cwd=HERE, text=True, capture_output=True, timeout=30)
            entry = {"id": identifier, "command": command, "command_shell": shlex.join(command), "expected_exit": expect_exit,
                     "actual_exit": proc.returncode, "expected_error_code": expect_code, "stdout": proc.stdout, "stderr": proc.stderr}
            passed = proc.returncode == expect_exit
            try:
                reply = json.loads(proc.stdout)
                if expect_code:
                    entry["actual_error_code"] = reply["code"]
                    passed = passed and reply["code"] == expect_code
                if scenario and passed:
                    out = Path(command[command.index("--out") + 1])
                    data = json.loads((out / "record.json").read_text())
                    entry["actual_record"] = data
                    entry["expected_observations"], entry["actual_observations"] = check_record(data, scenario, out)
                elif expect_exit == 0:
                    passed = False
            except (AssertionError, ValueError, KeyError, OSError) as error:
                entry["assertion_error"] = str(error)
                passed = False
            entry["passed"] = passed
            results.append(entry)
            log.extend(["\n## " + identifier, "$ " + entry["command_shell"], "expected exit=" + str(expect_exit) + " code=" + str(expect_code),
                        "actual exit=" + str(proc.returncode), "stdout:\n" + proc.stdout, "stderr:\n" + proc.stderr,
                        "exact checks=" + ("PASS" if passed else "FAIL"), json.dumps(entry, sort_keys=True)])
            return entry
        def command(before, after, out, context=None):
            value = [sys.executable, str(HERE / "record.py"), "--before", str(before), "--after", str(after), "--out", str(out)]
            if context:
                value += ["--context", str(context)]
            return value
        for scenario in SCENARIOS:
            identifier, before_name, after_name, context_name = scenario[:4]
            run(identifier, command(SNAP / before_name, SNAP / after_name, work / identifier, CTX / (context_name + ".json") if context_name else None), 0, scenario=scenario)
        repeat = SCENARIOS[1]
        run("R01_same_inputs_second_output", command(SNAP / repeat[1], SNAP / repeat[2], work / "repeat", CTX / (repeat[3] + ".json")), 0, scenario=repeat)
        same = all((work / repeat[0] / name).read_bytes() == (work / "repeat" / name).read_bytes() for name in ("record.json", "record.md"))
        invariants.append({"id": "I01_deterministic_records", "expected": "record.json and record.md byte-identical for same explicit inputs/context", "actual": same, "passed": same})
        bad = work / "bad"
        bad.mkdir()
        def context(name, content):
            p = bad / name
            p.write_bytes(content)
            return p
        base = SNAP / "baseline"
        def error_case(identifier, code, before=base, after=base, out=None, ctx=None):
            run(identifier, command(before, after, out or work / identifier, ctx), 2, code)
        error_case("E01_context_malformed", "CONTEXT_JSON", ctx=context("malformed.json", b'{'))
        error_case("E02_context_null", "CONTEXT_SHAPE", ctx=context("null.json", b'null'))
        error_case("E03_context_bad_channel", "CONTEXT_SHAPE", ctx=context("channel.json", b'{"schema_version":"1","channel":"auto"}'))
        error_case("E04_context_fake_actual", "CONTEXT_SHAPE", ctx=context("actual.json", b'{"schema_version":"1","actual_test_status":"PASS"}'))
        error_case("E05_missing_input", "INPUT_MISSING", before=bad / "missing")
        error_case("E06_file_as_snapshot", "INPUT_NOT_DIRECTORY", before=base / "plugin.json")
        for identifier, rel, target in [("E07_file_symlink", "link.txt", base / "plugin.json"), ("E08_directory_symlink", "link", base), ("E09_dangling_input_symlink", "link.txt", bad / "absent")]:
            tree = bad / identifier
            shutil.copytree(base, tree)
            (tree / rel).symlink_to(target)
            error_case(identifier, "INPUT_SYMLINK", before=tree)
        rootlink = bad / "rootlink"
        rootlink.symlink_to(base)
        error_case("E10_root_symlink", "INPUT_SYMLINK", before=rootlink)
        parentlink = bad / "parentlink"
        parentlink.symlink_to(SNAP)
        error_case("E11_ancestor_symlink", "INPUT_SYMLINK", before=parentlink / "baseline")
        contextlink = bad / "contextlink"
        contextlink.symlink_to(CTX / "local.json")
        error_case("E12_context_symlink", "INPUT_SYMLINK", ctx=contextlink)
        error_case("E13_output_inside_input", "OUTPUT_INSIDE_INPUT", out=base / "MUST-NOT-WRITE")
        error_case("E14_existing_record", "OUTPUT_EXISTS", out=work / SCENARIOS[0][0])
        outlink = bad / "outlink"
        outlink.symlink_to(bad / "nonexistent")
        error_case("E15_dangling_output_symlink", "OUTPUT_EXISTS", out=outlink)
        error_case("E16_output_parent_symlink", "INPUT_SYMLINK", out=parentlink / "new-output")
        error_case("E17_existing_output_file", "OUTPUT_EXISTS", out=bad / "null.json")
        error_case("E18_parent_traversal", "INPUT_PATH_BOUNDARY", before=bad / ".." / "bad")
        fifo = bad / "fifo-tree"
        shutil.copytree(base, fifo)
        os.mkfifo(fifo / "pipe")
        error_case("E19_special_file", "INPUT_NOT_REGULAR", before=fifo)
        big = bad / "large-tree"
        shutil.copytree(base, big)
        with (big / "too-large").open("wb") as handle:
            handle.truncate(8 * 1024 * 1024 + 1)
        error_case("E20_file_limit", "INPUT_RESOURCE_LIMIT", before=big)
        error_case("E21_duplicate_context_keys", "CONTEXT_JSON", ctx=context("duplicate.json", b'{"schema_version":"1","channel":"local_repository","channel":"public_directory"}'))
        error_case("E22_service_shape", "CONTEXT_SHAPE", ctx=context("service.json", b'{"schema_version":"1","service":{"implementation_change":"yes"}}'))
        deep = bad / "deep-tree"
        leaf = deep
        for _ in range(33):
            leaf = leaf / "d"
        leaf.mkdir(parents=True)
        error_case("E23_depth_limit", "INPUT_RESOURCE_LIMIT", before=deep)
        many = bad / "many-files"
        many.mkdir()
        for index in range(1025):
            (many / ("f%04d" % index)).write_bytes(b'')
        error_case("E24_file_count_limit", "INPUT_RESOURCE_LIMIT", before=many)
        error_case("E25_context_limit", "INPUT_RESOURCE_LIMIT", ctx=context("huge.json", b' ' * 65537))
        error_case("E26_missing_output_parent", "INPUT_MISSING", out=bad / "missing-parent" / "out")
        assert not (base / "MUST-NOT-WRITE").exists()
        summary = {"scope": "RECORDER_ENGINEERING_ONLY; every snapshot revision/declaration is simulation-only, not a release/host/platform result", "python": sys.version,
                   "scenario_commands": len(SCENARIOS), "repeat_commands": 1, "negative_input_boundary_commands": 26,
                   "subprocess_commands": len(results), "invariants": invariants, "assertions": len(results) + len(invariants),
                   "passed": sum(item["passed"] for item in results) + sum(item["passed"] for item in invariants),
                   "failed": sum(not item["passed"] for item in results) + sum(not item["passed"] for item in invariants), "results": results,
                   "all_actual_host_portal_service_tests": "NOT RUN"}
        log += ["\n## Invariants", json.dumps(invariants, sort_keys=True), "\n## Summary", json.dumps({key: value for key, value in summary.items() if key != "results"}, indent=2, sort_keys=True)]
        if evidence:
            evidence.mkdir(mode=0o700)
            (evidence / "validation.log").write_text("\n".join(log) + "\n")
            (evidence / "validation-summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        print(json.dumps({key: value for key, value in summary.items() if key != "results"}, indent=2, sort_keys=True))
        return 0 if summary["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
