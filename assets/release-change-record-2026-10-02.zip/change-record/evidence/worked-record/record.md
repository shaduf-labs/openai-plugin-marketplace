# Release change record

OFFLINE ENGINEERING ONLY — not a runtime submission ZIP or plugin validator.
Source rules checked: 2026-10-02 (retrieval date, not a release date).

## 1. Source / bundle: OBSERVED_OFFLINE
Classification: CHANGED_BYTES_SAME_VERSION
Manifest version relation: same

before input: "/srv/shaduf/workspaces/job-4d80646ec20c8644ce685fd5ee3a92a5f69c48d559de6977eb4c704a5d2fc531/workspace/runner/runs/5ba03869-db28-413a-8937-1156d3ac008b/change-record/fixtures/snapshots/baseline"
before snapshot fingerprint: 4ca3803a3d39acdb719745d4cadf56021c49ed5120daf21a4a5f63140d170a46
before root manifest: {"components": "UNKNOWN", "effective_openai_metadata": "unsupported-for-manifest-interpretation", "issues": [], "name": "meeting-evidence", "profile": "portable-root-plugin-json-identity-reading-v1", "schema_validation": "NOT RUN", "status": "portable-root-fields-read-not-validated", "version": "0.1.0"}

after input: "/srv/shaduf/workspaces/job-4d80646ec20c8644ce685fd5ee3a92a5f69c48d559de6977eb4c704a5d2fc531/workspace/runner/runs/5ba03869-db28-413a-8937-1156d3ac008b/change-record/fixtures/snapshots/instruction-same-version"
after snapshot fingerprint: 1980998fd12312c3b735ff66ff1ce2c0de29f8c44ef0e1f7aaa695f166c0f3f9
after root manifest: {"components": "UNKNOWN", "effective_openai_metadata": "unsupported-for-manifest-interpretation", "issues": [], "name": "meeting-evidence", "profile": "portable-root-plugin-json-identity-reading-v1", "schema_validation": "NOT RUN", "status": "portable-root-fields-read-not-validated", "version": "0.1.0"}

ADDED (0):
- none

REMOVED (0):
- none

CHANGED (1):
- "skills/meeting-evidence/SKILL.md" [skill]

UNCHANGED (1):
- "plugin.json" [manifest]

Fingerprints describe chosen file bytes/paths, not manifest release versions or installed/published copies.
File groups are coarse inventory aids, not component detection or policy/semantic conclusions.

## Reader context: READER_DECLARATION_NOT_OBSERVATION
{
  "basis": "READER_DECLARATION_NOT_OBSERVATION",
  "facts": {
    "channel": "public_directory",
    "declared_deployment_id": "UNKNOWN",
    "declared_loaded_source": "UNKNOWN",
    "declared_loaded_version": "UNKNOWN",
    "declared_published_version": "UNKNOWN",
    "declared_review_status": "UNKNOWN",
    "existing_public_listing_components": "UNKNOWN",
    "proposed_mcp_addition": "UNKNOWN",
    "provenance_note": "SIMULATION ONLY: no account, listing, deployment or service exists for this fixture.",
    "service": {
      "endpoint_after": "UNKNOWN",
      "endpoint_before": "UNKNOWN",
      "endpoint_change": "UNKNOWN",
      "implementation_change": "UNKNOWN",
      "permission_boundary_change": "UNKNOWN",
      "tool_addition": "UNKNOWN",
      "tool_contract_change": "UNKNOWN",
      "tool_removal": "UNKNOWN"
    },
    "simulation_only": true
  },
  "input_path": "/srv/shaduf/workspaces/job-4d80646ec20c8644ce685fd5ee3a92a5f69c48d559de6977eb4c704a5d2fc531/workspace/runner/runs/5ba03869-db28-413a-8937-1156d3ac008b/change-record/fixtures/contexts/public.json",
  "sha256": "ad2091696b27383ac60464913fae91e29042cedd907285dec493e30374073820"
}

## 2. Loaded host/session: NOT RUN; actual version/source/fingerprint UNKNOWN
## 3. Reviewed/published version: NOT RUN; actual version/review/publication UNKNOWN
## 4. Live backend deployment: NOT RUN; actual deployment/endpoint/contract UNKNOWN
Reader declarations NEVER replace these actual fields.

## Next evidence / recommendations
- OUR_MAINTENANCE_RECOMMENDATION [C01, C09]: Record actual loaded source/version and fresh-session behavior separately; source hashes never establish a host result.
- SOURCE_LINKED_RECOMMENDATION_CONDITIONED_ON_DECLARED_CHANNEL [C03, C10]: For intended bundled public updates, use the documented complete versioned ZIP/checks/review/Publish path. Choose the version yourself; this record is not an eligibility or submission-readiness verdict.

## Current source references
- C01: https://developers.openai.com/plugins/build/plugins — source, cache, restart, portable/overlay boundaries
- C02: https://agent-plugins.org/schemas/1.0.0/plugin.schema.json — optional version; root identity reading is not schema validation
- C03: https://developers.openai.com/plugins/deploy/submission — public bundled update: complete versioned ZIP, checks, review, Publish
- C04: https://developers.openai.com/plugins/deploy/submission — MCP scan/held/live tool definition boundary
- C05: https://developers.openai.com/plugins/deploy/app-review — live deployed implementation is not frozen by held metadata
- C06: https://developers.openai.com/plugins/deploy/submission — MCP addition to an existing skills-only listing currently unsupported
- C07: https://developers.openai.com/plugins/deploy/submission — existing MCP URL update unsupported; contact support
- C08: https://developers.openai.com/plugins/deploy/app-review — path/new version versus origin/new plugin guidance conflicts with C07
- C09: https://learn.chatgpt.com/docs/plugins — supported install/new-session procedure; no version inspection method established here
- C10: https://developers.openai.com/plugins/deploy/submission — portable version optional; explicit semantic version for public submission/updates

## Unknowns
- selected snapshots' completeness as intended runtime
- semantic correctness and impact
- effective components/settings
- actual installed/loaded version and current-session refresh
- actual public version/review/approval
- actual deployed code/tools/auth/permissions
- adopter access, propagation, review timing and rollback capability

## Exclusions
- whole-repository/runtime selection inference
- archive extraction or creation
- complete plugin/schema validation
- effective overlay/extension metadata
- component/service detection
- semantic diff or automatic version choice
- secret/safety scanning
- host installation/update/invocation
- portal/review/approval/publication
- network/deployment/authorization

Recorder limits (our policy, not platform rules): {"context_bytes": 65536, "depth": 32, "entries": 4096, "file_bytes": 8388608, "files": 1024, "manifest_parse_bytes": 1048576, "path_chars": 1024, "tree_bytes": 67108864}
